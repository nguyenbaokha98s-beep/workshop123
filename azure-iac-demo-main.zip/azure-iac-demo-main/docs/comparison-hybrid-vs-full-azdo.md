# Comparison: Two Migration Strategies for Bicep Deployment

## Overview

| | **Option A** — Hybrid | **Option B** — Full Azure DevOps |
|---|---|---|
| **Source Code** | GitHub | Azure DevOps Repos |
| **CI** (build, lint, test) | GitHub Actions | Azure Pipelines |
| **CD** (deploy infra) | Azure DevOps Pipelines | Azure DevOps Pipelines |
| **PR Reviews** | GitHub Pull Requests | Azure DevOps Pull Requests |
| **Dependabot** | ✅ Yes | ❌ Not available |

---

## Option A — Hybrid (GitHub + Azure DevOps)

> Source code & CI in GitHub, CD (deployment) in Azure DevOps

```
┌─────────────────────────────────────────────────────────────────┐
│                        GitHub                                   │
│                                                                 │
│  Source Code ──► PR opened ──► GitHub Actions (CI)              │
│                                  • Bicep Lint                   │
│                                  • Unit Tests                   │
│                                  • Dependabot auto-updates      │
│                                                                 │
│  PR merged to main ─────────────────────────┐                   │
└─────────────────────────────────────────────┼───────────────────┘
                                              │ webhook / trigger
┌─────────────────────────────────────────────▼───────────────────┐
│                     Azure DevOps                                │
│                                                                 │
│  Pipeline triggered ──► Validate ──► Deploy DEV ──► Deploy PROD │
│                                        (auto)     (approval)    │
│                                                                 │
│  • Service Connection (Workload Identity)                       │
│  • Environment gates & approvals                                │
│  • Deployment history & auditing                                │
└─────────────────────────────────────────────────────────────────┘
```

### What lives where

| Component | Location | Why |
|-----------|----------|-----|
| Source code (`infra/bicep/**`) | **GitHub** | Developers stay in GitHub for PRs, code review, issues |
| `dependabot.yml` | **GitHub** | GitHub-exclusive feature, keeps action versions updated |
| CI workflow (lint on PR) | **GitHub Actions** | Fast feedback on PRs without leaving GitHub |
| CD pipeline (deploy infra) | **Azure DevOps** | Better approval gates, service connections, audit trail |
| `AZURE_CREDENTIALS` secret | **Remove from GitHub** | Azure DevOps service connection replaces it |
| `gh secret set` / `gh variable set` steps | **Keep if needed** | Only if app deployment still runs from GitHub Actions |

### Pipeline file layout

```
.github/
  workflows/
    ci-bicep-lint.yml          ← CI only: lint + validate on PR (stays in GitHub)
  dependabot.yml               ← keeps GitHub Actions versions updated

pipelines/
  deploy-bicep-alpha.yml       ← CD: full deploy pipeline (runs in Azure DevOps)
```

### How to connect GitHub → Azure DevOps

1. **Azure DevOps Pipeline → GitHub repo**
   - Pipelines → New Pipeline → **GitHub** (install Azure Pipelines GitHub App)
   - Select repo `jacintobernier1996/azure-iac-demo`
   - Point to `pipelines/deploy-bicep-alpha.yml`
   - The `trigger:` and `pr:` sections in the YAML work with GitHub repos

2. **Trigger flow**
   - PR opened in GitHub → Azure DevOps runs **Validate stage only** (via `pr:` trigger)
   - PR merged to `main` → Azure DevOps runs **Validate → Deploy DEV → Deploy PROD**

### ✅ Pros
- **Developers stay in GitHub** — familiar workflow, PRs, issues, Copilot
- **Dependabot** keeps action versions & dependencies updated automatically
- **GitHub community features** — Discussions, Sponsors, Marketplace, CODEOWNERS
- **Best-of-both-worlds** — GitHub for dev experience, Azure DevOps for deployment control
- **No repo migration** — zero disruption to existing contributors
- **GitHub Advanced Security** — secret scanning, code scanning, dependency review

### ❌ Cons
- **Two systems to manage** — credentials, permissions, and dashboards split across two platforms
- **Pipeline YAML in GitHub, runs in Azure DevOps** — can confuse new team members
- **Cross-platform trigger latency** — GitHub webhook → Azure DevOps adds ~5-15s delay
- **Branch policies in two places** — GitHub branch protection + Azure DevOps build validation
- **Cost** — paying for both GitHub (Actions minutes) and Azure DevOps (Pipeline minutes)

---

## Option B — Full Azure DevOps

> Everything in Azure DevOps: source code, CI, and CD

```
┌─────────────────────────────────────────────────────────────────┐
│                     Azure DevOps (single platform)              │
│                                                                 │
│  Azure Repos ──► PR opened ──► Pipeline (CI stage)              │
│                                  • Bicep Lint                   │
│                                  • Validate                     │
│                                                                 │
│  PR merged to main ──► Pipeline (CD stages)                     │
│                          • Deploy DEV (auto)                    │
│                          • Deploy PROD (approval gate)          │
│                                                                 │
│  • Service Connection (Workload Identity)                       │
│  • Environment gates, approvals, business hours                 │
│  • Full deployment traceability                                 │
│  • Branch policies with build validation                        │
│  • Variable Groups & Secure Files                               │
└─────────────────────────────────────────────────────────────────┘
```

### What lives where

| Component | Location | Why |
|-----------|----------|-----|
| Source code (`infra/bicep/**`) | **Azure Repos** | Single platform, everything together |
| CI + CD pipeline | **Azure Pipelines** (single YAML) | One pipeline handles lint, validate, deploy |
| Environment approvals | **Azure DevOps Environments** | Built-in gates with approval, business hours, locks |
| Secrets | **Service Connections** | Managed by Azure AD, Workload Identity Federation |
| Branch protection | **Azure Repos Branch Policies** | Build validation, required reviewers, merge strategy |

### Pipeline file layout

```
pipelines/
  deploy-bicep-alpha.yml       ← Single pipeline: CI (validate) + CD (deploy)
```

### What you lose from GitHub

| GitHub Feature | Azure DevOps Equivalent | Gap |
|----------------|------------------------|-----|
| **Dependabot** | ❌ None built-in | Must use third-party tools (e.g., Renovate, WhiteSource) or manual updates |
| **GitHub Actions Marketplace** | Task extensions (marketplace.visualstudio.com) | Smaller ecosystem but covers Azure scenarios well |
| **GitHub Copilot** in PRs | Not available in Azure DevOps PRs | Can still use Copilot in VS Code locally |
| **CODEOWNERS** | Required reviewers per path (branch policies) | Slightly less flexible but functional |
| **GitHub Issues** | Azure Boards (richer for enterprise) | Actually an upgrade for project management |
| **GitHub Discussions** | ❌ None | Lose community discussion feature |
| **Secret Scanning** | Azure DevOps doesn't have auto secret scanning | Must use external tools (e.g., GitGuardian, CredScan in ADO) |
| **Dependency Graph** | ❌ None built-in | Must use external SCA tools |

### ✅ Pros
- **Single platform** — one place for code, pipelines, boards, artifacts
- **Unified permissions** — Azure AD RBAC across everything
- **No cross-platform latency** — triggers are instant
- **Richer enterprise features** — Azure Boards, Test Plans, Artifacts feed
- **Better for regulated industries** — single audit trail, compliance certifications
- **Service Connections** are first-class — no JSON secrets to manage
- **Cost simplicity** — one billing, included with Azure subscription (first 5 users free)

### ❌ Cons
- **Repo migration effort** — must migrate Git history, branches, PRs
- **No Dependabot** — manual or third-party dependency updates
- **Less developer mindshare** — GitHub is where most open-source developers work
- **No GitHub Copilot in PR reviews** — lose AI-assisted code review in PRs
- **Smaller action/extension ecosystem** — fewer community-contributed tasks
- **Azure Repos UI** is less polished than GitHub for code browsing

---

## Side-by-Side Comparison

| Dimension | **Option A** (Hybrid) | **Option B** (Full Azure DevOps) |
|-----------|----------------------|----------------------------------|
| **Setup complexity** | Medium — connect two platforms | Low — single platform |
| **Migration effort** | 🟢 Low — no repo move needed | 🔴 High — migrate repo + PRs + issues |
| **Developer experience** | 🟢 GitHub (familiar, Copilot) | 🟡 Azure DevOps (functional, less polished) |
| **Dependabot** | 🟢 Built-in | 🔴 Not available |
| **Secret scanning** | 🟢 GitHub Advanced Security | 🟡 Third-party needed |
| **Deployment approvals** | 🟢 Azure DevOps Environments | 🟢 Azure DevOps Environments |
| **Service connections** | 🟢 Workload Identity | 🟢 Workload Identity |
| **Audit trail** | 🟡 Split across two platforms | 🟢 Single platform |
| **Cost** | 🟡 GitHub + Azure DevOps | 🟢 Azure DevOps only |
| **Enterprise compliance** | 🟡 Two vendors to audit | 🟢 Single vendor (Microsoft) |
| **Branch policies** | 🟡 Two places to configure | 🟢 One place |
| **Team onboarding** | 🟡 Must learn two tools | 🟢 One tool to learn |
| **Open source friendly** | 🟢 GitHub is the standard | 🔴 Azure DevOps is enterprise-only |
| **CI speed (PR feedback)** | 🟢 Fast (GitHub → GitHub) | 🟢 Fast (ADO → ADO) |
| **CD trigger latency** | 🟡 ~5-15s webhook delay | 🟢 Instant |
| **Scalability** | 🟢 Both scale well | 🟢 Both scale well |

---

## Recommendation

### Choose **Option A (Hybrid)** if:
- ✅ Your team already uses GitHub daily and doesn't want to switch
- ✅ You have open-source components or external contributors
- ✅ You value Dependabot, GitHub Advanced Security, and Copilot in PRs
- ✅ You only need Azure DevOps for the **deployment pipeline** (CD)
- ✅ You want the lowest migration effort (no repo move)

### Choose **Option B (Full Azure DevOps)** if:
- ✅ Your organization is standardized on Azure DevOps
- ✅ You need a single audit trail for compliance (SOC2, ISO, etc.)
- ✅ You use Azure Boards for work item tracking
- ✅ You want unified permissions via Azure AD
- ✅ You prefer **one tool** over managing two platforms
- ✅ The project is internal/enterprise (not open source)

### 🏆 For this project (`azure-iac-demo`):

**Option A (Hybrid) is recommended** because:
1. The repo is already on GitHub — zero migration effort
2. Dependabot is valuable for keeping action versions and Bicep modules current
3. GitHub provides better developer experience for code review
4. Azure DevOps Environments give you the approval gates you need for prod
5. The pipeline YAML (`pipelines/deploy-bicep-alpha.yml`) already works with GitHub repos via the Azure Pipelines GitHub App

---

## Implementation: What to do for each option

### Option A — Quick Start

```bash
# 1. Keep repo on GitHub as-is
# 2. Install Azure Pipelines GitHub App
#    https://github.com/apps/azure-pipelines
# 3. In Azure DevOps:
#    - Create service connection
#    - Create 'dev' and 'prod' environments
#    - New Pipeline → GitHub → select repo → pipelines/deploy-bicep-alpha.yml
# 4. Optionally slim down GitHub Actions to CI-only (lint on PR)
# 5. Delete AZURE_CREDENTIALS secret from GitHub (no longer needed)
```

### Option B — Migration Steps

```bash
# 1. Import GitHub repo into Azure Repos
#    Azure DevOps → Repos → Import → paste GitHub clone URL
# 2. Create service connection (Workload Identity Federation)
# 3. Create 'dev' and 'prod' environments with approval gates
# 4. Create pipeline from pipelines/deploy-bicep-alpha.yml
# 5. Set up branch policies on 'main' (build validation, required reviewers)
# 6. Set up Renovate Bot or manual process for dependency updates
# 7. Archive the GitHub repo (or set to read-only mirror)
```
