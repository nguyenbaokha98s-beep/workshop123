# Migrating Bicep Deployment from GitHub Actions → Azure DevOps

## Files Created

| File | Purpose |
|------|---------|
| `.github/dependabot.yml` | Fixes missing Dependabot config — auto-updates `actions/checkout`, `azure/login`, etc. |
| `pipelines/deploy-bicep-alpha.yml` | Azure DevOps multi-stage pipeline (Validate → Dev → Prod) |

---

## What Moves to Azure DevOps vs What Stays in GitHub

### ✅ Move to Azure DevOps (Infrastructure Deployment)
| Concern | Why Azure DevOps is better |
|---------|---------------------------|
| **Bicep deployments** (`az stack sub create`) | Azure DevOps has native ARM service connections with Workload Identity Federation — no JSON credentials to rotate |
| **Environment approvals** (dev → prod gates) | Azure DevOps Environments have built-in approval gates, business-hours checks, and exclusive locks — richer than GitHub Environment protection rules |
| **Deployment history & auditing** | Azure DevOps Environments track every deployment per-resource with full traceability |
| **Secret management** | Azure DevOps service connections are managed by Azure AD — no `AZURE_CREDENTIALS` JSON secret needed |
| **Pipeline parameters** | `parameters:` in YAML give typed dropdowns (string, boolean, choice) on manual runs — cleaner than `workflow_dispatch` |

### ⏭️ Can Skip / Leave in GitHub
| Concern | Reason |
|---------|--------|
| **Dependabot** (`.github/dependabot.yml`) | GitHub-only feature — keeps action versions current; no equivalent needed in Azure DevOps |
| **GitHub-specific steps** (`gh secret set`, `gh variable set`) | Only needed if you still deploy app code from GitHub Actions. If all CI/CD moves to Azure DevOps, remove these. |
| **PR status checks** (lint on PR) | Azure DevOps can run the Validate stage on PRs via the `pr:` trigger — replaces GitHub PR checks |
| **`AZURE_CREDENTIALS` secret** | Azure DevOps uses service connections instead; delete this secret from GitHub once migrated |

---

## Azure DevOps Pipeline Architecture

```
┌─────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Validate    │────►│  Deploy → DEV   │────►│  Deploy → PROD  │
│  (Lint +     │     │  (auto on main) │     │  (manual gate)  │
│   Validate)  │     │                 │     │                 │
└─────────────┘     └─────────────────┘     └─────────────────┘
      │                                            ▲
      │ PR trigger                                 │
      └── runs only Validate                       │
                                        Approval required via
                                       Azure DevOps Environment
```

### Key Differences from GitHub Actions

| GitHub Actions | Azure DevOps | Notes |
|---------------|-------------|-------|
| `workflow_dispatch` + `inputs` | `parameters:` section | Both give UI dropdowns for manual runs |
| `environment: prod` + protection rules | `environment: 'prod'` + approval gate | Azure DevOps approvals are on the Environment object, not the YAML |
| `secrets.AZURE_CREDENTIALS` (JSON) | Service Connection (Workload Identity) | No secret rotation needed with Workload Identity Federation |
| `needs: validate` | `dependsOn: Validate` | Same concept, different syntax |
| `if: github.ref == 'refs/heads/main'` | `condition: ne(variables['Build.Reason'], 'PullRequest')` | PRs only run Validate |

---

## Setup Checklist in Azure DevOps

### 1. Create Service Connection
```
Project Settings → Service connections → New → Azure Resource Manager
  → Workload Identity Federation (recommended)
  → Name it: "azure-service-connection"
  → Grant subscription-level Contributor + RBAC Admin
```

### 2. Create Environments
```
Pipelines → Environments → New Environment
  → "dev"  (no approval needed)
  → "prod" (add Approval gate: Approvals and checks → Approvals → add approvers)
```

### 3. Create Pipeline

There are **4 ways** to create a pipeline in Azure DevOps:

#### Option A — Azure DevOps UI (most common)
```
Pipelines → New Pipeline → choose source:
  • Azure Repos Git   ← if code is in Azure DevOps
  • GitHub             ← if code stays on GitHub (installs Azure Pipelines GitHub App)
  • Bitbucket Cloud
  • Other Git (any HTTPS clone URL)

→ Select repo
→ Configure: "Existing Azure Pipelines YAML file"
→ Branch: main
→ Path: pipelines/deploy-bicep-alpha.yml
→ Run (or Save)
```

#### Option B — Azure CLI (`az pipelines create`)
```bash
# Install the Azure DevOps CLI extension
az extension add --name azure-devops

# Authenticate & set defaults
az devops configure --defaults organization=https://dev.azure.com/YOUR_ORG project=YOUR_PROJECT
az login

# Create pipeline from YAML in Azure Repos
az pipelines create \
  --name "Deploy Bicep Alpha" \
  --repository azure-iac-demo \
  --repository-type tfsgit \
  --branch main \
  --yml-path pipelines/deploy-bicep-alpha.yml

# OR create pipeline from YAML in GitHub
az pipelines create \
  --name "Deploy Bicep Alpha" \
  --repository jacintobernier1996/azure-iac-demo \
  --repository-type github \
  --branch main \
  --yml-path pipelines/deploy-bicep-alpha.yml \
  --service-connection "github-service-connection"
```

#### Option C — Azure DevOps REST API
```bash
# Useful for automation / Infrastructure-as-Code for pipelines themselves
curl -X POST \
  "https://dev.azure.com/{org}/{project}/_apis/pipelines?api-version=7.1" \
  -H "Content-Type: application/json" \
  -H "Authorization: Basic $(echo -n :$PAT | base64)" \
  -d '{
    "name": "Deploy Bicep Alpha",
    "folder": "/",
    "configuration": {
      "type": "yaml",
      "path": "pipelines/deploy-bicep-alpha.yml",
      "repository": {
        "id": "<repo-id>",
        "type": "azureReposGit"
      }
    }
  }'
```

#### Option D — Terraform / Bicep (Pipeline-as-Code)
```hcl
# Using the azuredevops Terraform provider
resource "azuredevops_build_definition" "bicep_alpha" {
  project_id = azuredevops_project.main.id
  name       = "Deploy Bicep Alpha"

  ci_trigger { use_yaml = true }

  repository {
    repo_type   = "TfsGit"                              # or "GitHub"
    repo_id     = azuredevops_git_repository.main.id
    branch_name = "refs/heads/main"
    yml_path    = "pipelines/deploy-bicep-alpha.yml"
  }
}
```

#### Comparison of methods

| Method | Best for | Pros | Cons |
|--------|----------|------|------|
| **UI** | Getting started, one-time setup | Visual, easy, no tooling needed | Manual, not repeatable |
| **Azure CLI** | Scripted setup, onboarding automation | Repeatable, scriptable | Must install CLI extension |
| **REST API** | CI/CD for pipelines, custom tooling | Full control, any language | Verbose, must manage PAT |
| **Terraform** | GitOps, managing Azure DevOps itself as IaC | Declarative, version-controlled, drift detection | Extra provider dependency |

> 💡 **Recommendation**: Use the **UI** for initial setup, then consider **Terraform** if you want to manage Azure DevOps configuration as code alongside your Bicep infrastructure.

### 4. (Optional) Variable Group
```
Pipelines → Library → + Variable Group → "bicep-alpha-vars"
  → Add any override variables if needed
```

### 5. Branch Policy (replaces GitHub branch protection)
```
Repos → Branches → main → Branch policies
  → Build validation → Add → select the pipeline → trigger on PR
```

---

## Mapping: GitHub Actions → Azure DevOps YAML

```yaml
# GitHub Actions                    # Azure DevOps
on: workflow_dispatch           →   trigger: + parameters:
jobs:                           →   stages: → jobs:
  runs-on: ubuntu-latest        →     pool: vmImage: 'ubuntu-latest'
  environment: prod             →     environment: 'prod'
  uses: azure/login@v2          →     task: AzureCLI@2
  run: |                        →     inlineScript: |
  secrets.AZURE_CREDENTIALS     →     azureSubscription: $(svcConn)
  needs: validate               →     dependsOn: Validate
  if: condition                 →     condition: expression
```
