# Self-Hosted Azure DevOps Agent on Azure VM

> **Why?** Free-tier Azure DevOps organizations have **zero** Microsoft-hosted
> parallel jobs.  A self-hosted agent on an Azure VM is the fastest way to
> unblock your pipelines while you wait for a free parallelism grant (or
> permanently, to save costs).

---

## Architecture

```
Azure DevOps Org
  └── Agent Pool: "AzureVMPool"
        └── Agent: "agent-vm-01"  ←─── Ubuntu 22.04 VM in Azure
                                        (Azure CLI + Bicep pre-installed)
```

---

## Naming Convention (Shared Subscription)

Every student uses their name as a **suffix** to ensure unique resource names:

| Resource | Pattern | Example (suffix = `jacinto`) |
|----------|---------|------------------------------|
| Stack | `agent-vm-stack-{suffix}` | `agent-vm-stack-jacinto` |
| Resource Group | `agent-build-rg-{suffix}` | `agent-build-rg-jacinto` |
| VM | `agent-build-vm-{suffix}` | `agent-build-vm-jacinto` |
| Public IP | `agent-build-pip-{suffix}` | `agent-build-pip-jacinto` |
| VNet | `agent-build-vnet-{suffix}` | `agent-build-vnet-jacinto` |
| NSG | `agent-build-nsg-{suffix}` | `agent-build-nsg-jacinto` |
| NIC | `agent-build-nic-{suffix}` | `agent-build-nic-jacinto` |

---

## Prerequisites

### 1. Create the Agent Pool in Azure DevOps

1. Go to **Azure DevOps** → **Organization Settings** → **Agent pools**
2. Click **Add pool**
3. Pool type: **Self-hosted**
4. Name: **`AzureVMPool`**
5. Check ✅ **Grant access permission to all pipelines**
6. Click **Create**

### 2. Get a Personal Access Token (PAT)

1. Go to **Azure DevOps** → top-right avatar → **Personal access tokens**
2. Click **+ New Token**
3. Name: `self-hosted-agent`
4. Scope: **Agent Pools (Read & manage)**
5. Expiration: up to 1 year
6. Click **Create** and **copy the token** (you won't see it again)

### 3. Generate an SSH Key Pair

If you don't already have an SSH key, generate one:

```bash
# Linux / macOS / WSL
ssh-keygen -t ed25519 -C "your-email@example.com" -f ~/.ssh/id_agent_vm
```

```powershell
# Windows PowerShell
ssh-keygen -t ed25519 -C "your-email@example.com" -f "$env:USERPROFILE\.ssh\id_agent_vm"
```

This creates two files:
- **Private key**: `~/.ssh/id_agent_vm` (keep this safe, use it to SSH into the VM)
- **Public key**: `~/.ssh/id_agent_vm.pub` (this goes into GitHub Secrets)

Copy the public key content:

```bash
# Linux / macOS / WSL
cat ~/.ssh/id_agent_vm.pub
```

```powershell
# Windows PowerShell
Get-Content "$env:USERPROFILE\.ssh\id_agent_vm.pub"
```

### 4. Add Secrets in GitHub

Go to your GitHub repo → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**

Add these **4 secrets**:

| Secret Name | Value | How to get it |
|-------------|-------|---------------|
| `AZURE_CREDENTIALS` | Azure Service Principal JSON | `az ad sp create-for-rbac --name "github-deployer" --role Contributor --scopes /subscriptions/<SUB_ID> --sdk-auth` |
| `AZDO_ORG_URL` | `https://dev.azure.com/<YOUR_ORG>` | Your Azure DevOps organization URL |
| `AZDO_PAT` | Personal Access Token | From step 2 above |
| `AGENT_VM_SSH_PUBLIC_KEY` | SSH public key contents | From step 3 above (the contents of `id_agent_vm.pub`) |

> ⚠️ For `AZURE_CREDENTIALS`, run:
> ```bash
> az ad sp create-for-rbac \
>   --name "github-deployer" \
>   --role Contributor \
>   --scopes /subscriptions/<YOUR_SUBSCRIPTION_ID> \
>   --sdk-auth
> ```
> Copy the entire JSON output and paste it as the secret value.

---

## Option A — Deploy via GitHub Actions (Recommended)

The workflow `.github/workflows/deploy-agent-vm.yml` handles validate → deploy automatically.

### Step 1: Trigger the workflow

1. Go to GitHub repo → **Actions** → **Deploy Agent VM Infrastructure**
2. Click **Run workflow**
3. Fill in the inputs:

| Input | Value | Example |
|-------|-------|---------|
| **location** | Azure region | `eastasia` |
| **projectName** | Resource name prefix | `agent-build` |
| **suffix** | Your student name (required) | `jacinto` |
| **agentPool** | Azure DevOps pool name | `AzureVMPool` |
| **agentName** | Agent display name | `agent-vm-01` |
| **vmSize** | VM SKU | `Standard_B2ats_v2` |

4. Click **Run workflow**

The pipeline will:
1. **Validate** — lint the Bicep and validate the deployment stack
2. **Deploy** — create the resource group, VM, networking, and auto-configure the agent via cloud-init

### Step 2: Check deployment outputs

After the workflow completes, the **Print deployment summary** step shows:

```
╔══════════════════════════════════════════════════════════════╗
║              Agent VM Deployment Summary                     ║
╠══════════════════════════════════════════════════════════════╣
║  Project:         agent-build                                ║
║  Suffix:          jacinto                                    ║
║  Stack:           agent-vm-stack-jacinto                     ║
║  Resource Group:  agent-build-rg-jacinto                     ║
╠══════════════════════════════════════════════════════════════╣
║  VM Name:         agent-build-vm-jacinto                     ║
║  Public IP:       20.xxx.xxx.xxx                             ║
║  SSH:             ssh azureuser@20.xxx.xxx.xxx               ║
╠══════════════════════════════════════════════════════════════╣
║  Agent Pool:      AzureVMPool                                ║
║  Agent Name:      agent-vm-01                                ║
╚══════════════════════════════════════════════════════════════╝
```

Or query outputs via CLI:

```bash
az stack sub show \
  --name "agent-vm-stack-jacinto" \
  --query "outputs" -o table
```

### Step 3: Wait for cloud-init (~5-10 minutes)

The VM needs time after creation to run the cloud-init script that installs
Azure CLI, Bicep, downloads the agent, and starts the service.

SSH in to watch progress:

```bash
ssh -i ~/.ssh/id_agent_vm azureuser@<PUBLIC_IP>

# Watch the install log in real-time
tail -f /var/log/azagent-install.log

# Or check if cloud-init finished
cloud-init status
```

### Step 4: Verify agent is online

1. Go to **Azure DevOps** → **Organization Settings** → **Agent pools** → **AzureVMPool**
2. Click the **Agents** tab
3. Confirm the agent shows as 🟢 **Online**

---

## Option B — Deploy via Azure CLI (Manual)

If you prefer to deploy directly from your terminal instead of GitHub Actions:

### Generate SSH key (if not done)

```bash
ssh-keygen -t ed25519 -C "your-email@example.com" -f ~/.ssh/id_agent_vm
```

### Deploy the stack

```bash
# Replace <YOUR_ORG>, <YOUR_PAT>, and <YOUR_NAME> with your values

# 1. Validate first
az stack sub validate \
  --name "agent-vm-stack-<YOUR_NAME>" \
  --location eastasia \
  --template-file infra/bicep/agent-vm.bicep \
  --parameters infra/bicep/envs/agent-vm.bicepparam \
    projectName="agent-build" \
    suffix="<YOUR_NAME>" \
    azdoOrgUrl="https://dev.azure.com/<YOUR_ORG>" \
    azdoPat="<YOUR_PAT>" \
    adminPasswordOrKey="$(cat ~/.ssh/id_agent_vm.pub)" \
  --action-on-unmanage deleteAll \
  --deny-settings-mode none

# 2. Deploy
az stack sub create \
  --name "agent-vm-stack-<YOUR_NAME>" \
  --location eastasia \
  --template-file infra/bicep/agent-vm.bicep \
  --parameters infra/bicep/envs/agent-vm.bicepparam \
    projectName="agent-build" \
    suffix="<YOUR_NAME>" \
    azdoOrgUrl="https://dev.azure.com/<YOUR_ORG>" \
    azdoPat="<YOUR_PAT>" \
    adminPasswordOrKey="$(cat ~/.ssh/id_agent_vm.pub)" \
  --action-on-unmanage deleteAll \
  --deny-settings-mode none \
  --yes
```

### Check outputs

```bash
az stack sub show \
  --name "agent-vm-stack-<YOUR_NAME>" \
  --query "outputs" -o table
```

### Tear down everything

```bash
az stack sub delete \
  --name "agent-vm-stack-<YOUR_NAME>" \
  --action-on-unmanage deleteAll \
  --yes
```

---

## File Structure

```
infra/bicep/
├── agent-vm.bicep              ← subscription-scoped entry point (creates RG + calls module)
├── envs/
│   └── agent-vm.bicepparam     ← default parameters
└── modules/
    └── agent-vm.bicep          ← VM + networking resources + cloud-init

.github/workflows/
└── deploy-agent-vm.yml         ← GitHub Action to deploy the agent VM
```

---

## Pipeline Configuration

Use the self-hosted pool in your Azure DevOps pipeline:

```yaml
pool:
  name: "AzureVMPool"    # Self-hosted agent pool
```

To switch back to Microsoft-hosted agents (after getting the parallelism grant):

```yaml
pool:
  vmImage: "ubuntu-latest"
```

---

## Maintenance & Tips

| Task | Command |
|------|---------|
| **SSH into the VM** | `ssh -i ~/.ssh/id_agent_vm azureuser@<PUBLIC_IP>` |
| **Check agent install log** | `tail -f /var/log/azagent-install.log` |
| **Check cloud-init log** | `sudo cat /var/log/cloud-init-output.log` |
| **Check agent service** | `sudo /opt/azagent/svc.sh status` |
| **Restart agent** | `sudo /opt/azagent/svc.sh stop && sudo /opt/azagent/svc.sh start` |
| **Agent diagnostics** | `cat /opt/azagent/_diag/Agent_*.log` |
| **systemd journal** | `sudo journalctl -u vsts.agent.* -f` |
| **Update Azure CLI** | `sudo apt-get update && sudo apt-get install azure-cli` |
| **Deallocate VM (save cost)** | `az vm deallocate -g agent-build-rg-<NAME> -n agent-build-vm-<NAME>` |
| **Start VM** | `az vm start -g agent-build-rg-<NAME> -n agent-build-vm-<NAME>` |

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Agent shows **Offline** | SSH in → `sudo /opt/azagent/svc.sh start` |
| cloud-init still running | `cloud-init status` — wait for `status: done` |
| cloud-init failed | `cat /var/log/azagent-install.log` — check which step failed |
| Download agent failed | Check URL in log — needs `download.agent.dev.azure.com` (v5.x) |
| config.sh failed | Check PAT is valid, pool exists, org URL correct |
| `az: command not found` in pipeline | SSH in → `curl -sL https://aka.ms/InstallAzureCLIDeb \| sudo bash` |
| Pipeline hangs on "Waiting for agent" | Check pool name matches (`AzureVMPool`) |
| Permission denied on service connection | Grant the pool access in Project Settings → Service connections |
| SSH connection refused | VM may still be booting; wait 1-2 min. Check NSG allows port 22. |
