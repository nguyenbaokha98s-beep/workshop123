# azure-iac-demo

Infrastructure-as-Code demo deploying an Azure **Resource Group** + **Static Web App** to **dev** and **prod** environments using both **Bicep** and **Terraform**, with GitHub Actions CI/CD pipelines.

---

## Repository structure

```
.
├── .github/
│   └── workflows/
│       ├── deploy-bicep.yml       # Bicep pipeline (validate → deploy dev → deploy prod)
│       └── deploy-terraform.yml   # Terraform pipeline (plan → apply dev → apply prod)
└── infra/
    ├── bicep/
    │   ├── main.bicep             # Subscription-scoped entry point
    │   ├── modules/
    │   │   └── static-web-app.bicep
    │   └── envs/
    │       ├── dev.bicepparam
    │       └── prod.bicepparam
    └── terraform/
        ├── main.tf
        ├── variables.tf
        ├── outputs.tf
        └── envs/
            ├── dev.tfvars
            └── prod.tfvars
```

---

## Prerequisites

| Tool | Version |
|------|---------|
| Azure CLI | ≥ 2.60 |
| Bicep CLI | ≥ 0.29 (`az bicep install`) |
| Terraform | ≥ 1.5 |
| Azure subscription | Contributor or Owner role |

---

## Azure authentication setup (for GitHub Actions)

The pipelines authenticate using a **Service Principal client secret**.

### Step 1 — Login and get your Subscription ID & Tenant ID

```bash
az login
az account show --query "{subscriptionId:id, tenantId:tenantId}" -o table
```

Copy both values — you will need them in Step 3.

### Step 2 — Create a Service Principal

```bash
az ad sp create-for-rbac \
  --name "github-iac-demo" \
  --role Contributor \
  --scopes /subscriptions/<SUBSCRIPTION_ID> \
  --sdk-auth
```

Copy the entire JSON output — you will paste it as the `AZURE_CREDENTIALS` secret in Step 3.

> ⚠️ The `clientSecret` inside the JSON is only shown once.

### Step 3 — Add secrets to GitHub

Go to **GitHub → your repo → Settings → Secrets and variables → Actions → New repository secret** and add:

| Secret name | Value |
|-------------|-------|
| `AZURE_CREDENTIALS` | The full JSON output from Step 2 |

### Step 4 — Create GitHub Environments

In **GitHub → Settings → Environments**:

1. Create a `dev` environment (no restrictions needed).
2. Create a `prod` environment and add a **required reviewer** for the manual approval gate.

---

## Deploy manually

### Bicep

```bash
# What-if (dev)
az deployment sub what-if \
  --location southeastasia \
  --template-file infra/bicep/main.bicep \
  --parameters infra/bicep/envs/dev.bicepparam

# Deploy dev
az deployment sub create \
  --location southeastasia \
  --template-file infra/bicep/main.bicep \
  --parameters infra/bicep/envs/dev.bicepparam \
  --name "bicep-dev-manual"

# Deploy prod
az deployment sub create \
  --location southeastasia \
  --template-file infra/bicep/main.bicep \
  --parameters infra/bicep/envs/prod.bicepparam \
  --name "bicep-prod-manual"
```

### Terraform

```bash
cd infra/terraform

terraform init
terraform validate

# dev
terraform plan  -var-file="envs/dev.tfvars"  -out="dev.tfplan"
terraform apply dev.tfplan

# prod
terraform plan  -var-file="envs/prod.tfvars"  -out="prod.tfplan"
terraform apply prod.tfplan
```

---

## CI/CD pipelines

Both pipelines are triggered on pushes to `main` that touch their `infra/` path, and can also be run via **workflow_dispatch**.

| Pipeline | Trigger path | Jobs |
|----------|-------------|------|
| `deploy-bicep.yml` | `infra/bicep/**` | validate (matrix) → deploy-dev → deploy-prod |
| `deploy-terraform.yml` | `infra/terraform/**` | plan (matrix) → apply-dev → apply-prod |

`prod` jobs are gated by the **GitHub Environment** protection rule (manual approval).

---

## Environment differences

| Setting | dev | prod |
|---------|-----|------|
| SKU | Free | Standard |
| Manual approval gate | ✗ | ✓ |
