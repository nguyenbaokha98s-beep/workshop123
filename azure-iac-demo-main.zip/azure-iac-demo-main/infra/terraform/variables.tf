variable "project_name" {
  description = "Name of the project (used in resource naming)"
  type        = string
  default     = "todo-app-tf"

  validation {
    condition     = length(var.project_name) >= 2 && length(var.project_name) <= 20
    error_message = "project_name must be between 2 and 20 characters."
  }
}

variable "environment" {
  description = "Deployment environment"
  type        = string

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be one of: dev, staging, prod."
  }
}

variable "location" {
  description = "Azure region for the resource group"
  type        = string
  default     = "southeastasia"
}

variable "swa_location" {
  description = "Azure region for the Static Web App (limited availability)"
  type        = string
  default     = "southeastasia"
}

variable "sku_tier" {
  description = "SKU tier for the Static Web App"
  type        = string
  default     = "Free"

  validation {
    condition     = contains(["Free", "Standard"], var.sku_tier)
    error_message = "sku_tier must be either 'Free' or 'Standard'."
  }
}
