output "resource_group_name" {
  description = "Name of the provisioned resource group"
  value       = azurerm_resource_group.main.name
}

output "static_web_app_id" {
  description = "Resource ID of the Static Web App"
  value       = azurerm_static_web_app.main.id
}

output "static_web_app_url" {
  description = "Default hostname of the Static Web App"
  value       = "https://${azurerm_static_web_app.main.default_host_name}"
}

output "static_web_app_name" {
  description = "Name of the Static Web App"
  value       = azurerm_static_web_app.main.name
}

output "deployment_token_command" {
  description = "CLI command to retrieve the deployment API key"
  value       = "az staticwebapp secrets list --name ${azurerm_static_web_app.main.name} --query \"properties.apiKey\" -o tsv"
}
