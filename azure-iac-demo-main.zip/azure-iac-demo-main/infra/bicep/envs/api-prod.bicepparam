using '../main-api.bicep'

param projectName = 'todo-app-bicep'
param environment = 'prod'
param location = 'eastasia'
param skuName = 'P1v3'
param linuxFxVersion = 'NODE|20-lts'
