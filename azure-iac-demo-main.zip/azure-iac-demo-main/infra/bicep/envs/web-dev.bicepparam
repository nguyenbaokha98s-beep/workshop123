using '../main.bicep'

param projectName = 'todo-app-bicep'
param environment = 'dev'
param location = 'eastasia'
param swaLocation = 'eastasia'
param skuTier = 'Free'
param customDomain = ''
