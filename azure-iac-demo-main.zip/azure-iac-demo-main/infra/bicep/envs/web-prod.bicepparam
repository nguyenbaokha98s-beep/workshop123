using '../main.bicep'

param projectName = 'todo-app-bicep'
param environment = 'prod'
param location = 'eastasia'
param swaLocation = 'eastasia'
param skuTier = 'Standard'
param customDomain = ''
