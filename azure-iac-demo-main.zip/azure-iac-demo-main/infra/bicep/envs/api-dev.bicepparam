using '../main-api.bicep'

param projectName = 'todo-app-bicep'
param environment = 'dev'
param location = 'eastasia'
param skuName = 'B1'
param linuxFxVersion = 'NODE|20-lts'
