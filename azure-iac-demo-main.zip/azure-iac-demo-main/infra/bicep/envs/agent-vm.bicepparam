using '../agent-vm.bicep'

param projectName = 'agent-build'
param suffix = ''                  // student name (e.g. 'jacinto') → agent-build-vm-jacinto
param location = 'eastasia'
param adminUsername = 'azureuser'

// ⚠️ Sensitive — pass these at deploy time via CLI, not in source control:
//   --parameters azdoOrgUrl="..." azdoPat="..." adminPasswordOrKey="..."
param azdoOrgUrl = ''              // e.g. https://dev.azure.com/YOUR_ORG
param azdoPat = ''                 // PAT with Agent Pools (Read & manage)
param adminPasswordOrKey = ''      // SSH public key contents

param agentPool = 'AzureVMPool'
param agentName = 'agent-vm-01'
param vmSize = 'Standard_B2ats_v2'
param authenticationType = 'sshPublicKey'
param agentVersion = '5.270.0'
