// Azure App Service (Web API) — main entry point (subscription scope)
// Provisions a resource group and delegates to the app-service module.

targetScope = 'subscription'

@description('Name of the project (used in resource naming)')
@minLength(2)
@maxLength(20)
param projectName string = 'todo-app-bicep'

@description('Deployment environment')
@allowed(['dev', 'staging', 'prod'])
param environment string = 'dev'

@description('Azure region for the resource group and App Service')
param location string = 'eastasia'

@description('App Service Plan SKU name (e.g. B1 for dev, P1v3 for prod)')
param skuName string = 'B1'

@description('Linux runtime stack (e.g. DOTNETCORE|8.0, NODE|20-lts, PYTHON|3.11)')
param linuxFxVersion string = 'DOTNETCORE|8.0'

// Resource Group
resource rg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: '${projectName}-${environment}-api-rg'
  location: location
  tags: {
    Project: projectName
    Environment: environment
    ManagedBy: 'Bicep'
    Application: 'Web API'
  }
}

// App Service module
module appService 'modules/app-service.bicep' = {
  scope: rg
  name: 'appServiceDeploy'
  params: {
    projectName: projectName
    environment: environment
    location: location
    skuName: skuName
    linuxFxVersion: linuxFxVersion
    tags: {
      Project: projectName
      Environment: environment
      ManagedBy: 'Bicep'
      Application: 'Web API'
    }
  }
}

// Outputs
@description('Resource group name')
output resourceGroupName string = rg.name

@description('App Service resource ID')
output appServiceId string = appService.outputs.appServiceId

@description('App Service default URL')
output appServiceUrl string = appService.outputs.appServiceUrl

@description('App Service name')
output appServiceName string = appService.outputs.appServiceName
