// Azure Static Web App - main entry point (subscription scope)
// Provisions a resource group and delegates to the static-web-app module.

targetScope = 'subscription'

@description('Name of the project (used in resource naming)')
@minLength(2)
@maxLength(20)
param projectName string = 'todo-app-bicep'

@description('Deployment environment')
@allowed(['dev', 'staging', 'prod'])
param environment string = 'dev'

@description('Azure region for the resource group')
param location string = 'eastasia'

@description('Azure region for the Static Web App (limited availability)')
param swaLocation string = 'eastasia'

@description('SKU tier for the Static Web App')
@allowed(['Free', 'Standard'])
param skuTier string = 'Free'

@description('Custom domain name (leave empty to skip)')
param customDomain string = ''

// Resource Group
resource rg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: '${projectName}-${environment}-rg'
  location: location
  tags: {
    Project: projectName
    Environment: environment
    ManagedBy: 'Bicep'
    Application: 'Todo Application'
  }
}

// Static Web App module
module staticWebApp 'modules/static-web-app.bicep' = {
  scope: rg
  params: {
    projectName: projectName
    environment: environment
    location: swaLocation
    skuTier: skuTier
    customDomain: customDomain
    tags: {
      Project: projectName
      Environment: environment
      ManagedBy: 'Bicep'
      Application: 'Todo Frontend'
    }
  }
}

// Outputs
@description('Resource group name')
output resourceGroupName string = rg.name

@description('Static Web App resource ID')
output staticWebAppId string = staticWebApp.outputs.staticWebAppId

@description('Static Web App default hostname')
output staticWebAppUrl string = staticWebApp.outputs.staticWebAppUrl

@description('Static Web App name')
output staticWebAppName string = staticWebApp.outputs.staticWebAppName

@description('Command to retrieve the deployment token')
output deploymentTokenCommand string = 'az staticwebapp secrets list --name ${staticWebApp.outputs.staticWebAppName} --query "properties.apiKey" -o tsv'
