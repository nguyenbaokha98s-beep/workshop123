// Module: Azure DevOps Self-Hosted Agent VM
// Deploys an Ubuntu 22.04 VM with Azure CLI, Bicep, Docker, and the Azure Pipelines
// agent pre-configured via cloud-init.
// This module is resource-group scoped — called from agent-vm.bicep.
//
// Naming convention:
//   No suffix  → {projectName}-{resourceType}        e.g. agent-build-vm
//   With suffix→ {projectName}-{resourceType}-{suffix} e.g. agent-build-vm-01

@description('Project name used as prefix for all resource names.')
@minLength(2)
@maxLength(30)
param projectName string

@description('Student name used as suffix for unique resource names in a shared subscription. Leave empty to skip.')
param suffix string = ''

@description('Location for all resources.')
param location string = resourceGroup().location

@description('Admin username for the VM.')
param adminUsername string = 'azureuser'

@secure()
@description('SSH public key or password for the admin user.')
param adminPasswordOrKey string

@allowed(['sshPublicKey', 'password'])
@description('Authentication type: SSH key (recommended) or password.')
param authenticationType string = 'sshPublicKey'

@description('VM size. B2s is sufficient for a build agent.')
param vmSize string = 'Standard_B2s'

@description('Azure DevOps organization URL, e.g. https://dev.azure.com/myorg')
param azdoOrgUrl string

@secure()
@description('Personal Access Token with Agent Pools (Read & manage) scope.')
param azdoPat string

@description('Name of the agent pool in Azure DevOps.')
param agentPool string = 'AzureVMPool'

@description('Name for the agent (visible in Azure DevOps).')
param agentName string = 'agent-vm-01'

@description('Azure Pipelines agent version (v5.x uses download.agent.dev.azure.com).')
param agentVersion string = '5.270.0'

@description('Tags to apply to all resources.')
param tags object = {}

// ── Naming ──────────────────────────────────────────────────────────────────
// Pattern: {projectName}-{resourceType} or {projectName}-{resourceType}-{suffix}
var nameSuffix = !empty(suffix) ? '-${suffix}' : ''
var vmName = '${projectName}-vm${nameSuffix}'
var nicName = '${projectName}-nic${nameSuffix}'
var nsgName = '${projectName}-nsg${nameSuffix}'
var vnetName = '${projectName}-vnet${nameSuffix}'
var subnetName = '${projectName}-snet${nameSuffix}'
var pipName = '${projectName}-pip${nameSuffix}'

var linuxConfiguration = {
  disablePasswordAuthentication: true
  ssh: {
    publicKeys: [
      {
        path: '/home/${adminUsername}/.ssh/authorized_keys'
        keyData: adminPasswordOrKey
      }
    ]
  }
}

// ── cloud-init script ───────────────────────────────────────────────────────
// Placeholders use __PLACEHOLDER__ style to avoid Bicep interpolation conflicts.
// All steps log to /var/log/azagent-install.log for troubleshooting.
// SSH into VM and run:  tail -f /var/log/azagent-install.log
//                       sudo cat /var/log/cloud-init-output.log
var cloudInit = '''
#cloud-config
package_update: true
package_upgrade: true
packages:
  - git
  - zip
  - unzip
  - jq
  - curl
  - apt-transport-https
  - ca-certificates
  - lsb-release
  - gnupg

write_files:
  - path: /usr/local/bin/install-agent.sh
    permissions: "0755"
    content: |
      #!/bin/bash
      set -euo pipefail
      LOG="/var/log/azagent-install.log"
      exec > >(tee -a "$LOG") 2>&1
      log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }
      AGENT_DIR="/opt/azagent"
      log "=========================================="
      log "Azure DevOps Agent Installation - START"
      log "=========================================="
      log "OS:            $(lsb_release -ds 2>/dev/null || head -1 /etc/os-release)"
      log "Kernel:        $(uname -r)"
      log "Admin user:    __ADMIN_USER__"
      log "Agent version: __AGENT_VERSION__"
      log "Agent name:    __AGENT_NAME__"
      log "Agent pool:    __AGENT_POOL__"
      log "Org URL:       __AZDO_ORG_URL__"
      log "──── Step 1/9: Installing Azure CLI ────"
      if command -v az &>/dev/null; then
        log "Azure CLI already installed: $(az version --output tsv 2>/dev/null | head -1)"
      else
        curl -sL https://aka.ms/InstallAzureCLIDeb | bash
        log "Azure CLI installed: $(az version --output tsv 2>/dev/null | head -1)"
      fi
      log "──── Step 2/9: Installing Bicep ────"
      az bicep install
      log "Bicep version: $(az bicep version 2>/dev/null)"
      log "──── Step 3/9: Installing Docker ────"
      if command -v docker &>/dev/null; then
        log "Docker already installed: $(docker --version)"
      else
        curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
        echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" > /etc/apt/sources.list.d/docker.list
        apt-get update
        apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
        systemctl enable docker
        systemctl start docker
        usermod -aG docker __ADMIN_USER__
        log "Docker installed: $(docker --version)"
        log "Docker Compose: $(docker compose version)"
      fi
      log "──── Step 4/9: Preparing $AGENT_DIR ────"
      rm -rf "$AGENT_DIR"
      mkdir -p "$AGENT_DIR"
      cd "$AGENT_DIR"
      log "Working directory: $(pwd)"
      AGENT_URL="https://download.agent.dev.azure.com/agent/__AGENT_VERSION__/vsts-agent-linux-x64-__AGENT_VERSION__.tar.gz"
      log "──── Step 5/9: Downloading agent ────"
      log "URL: $AGENT_URL"
      if curl -fSL --retry 3 --retry-delay 5 -o vsts-agent.tar.gz "$AGENT_URL"; then
        log "Download OK — size: $(du -h vsts-agent.tar.gz | cut -f1)"
      else
        log "ERROR: Download FAILED. Tried: $AGENT_URL"
        exit 1
      fi
      log "──── Step 6/9: Extracting agent ────"
      log "Archive contents (top-level):"
      (tar tzf vsts-agent.tar.gz || true) | head -30 | while read -r line; do log "  $line"; done
      tar xzf vsts-agent.tar.gz
      rm -f vsts-agent.tar.gz
      log "Extracted directory listing:"
      ls -la "$AGENT_DIR" | while read -r line; do log "  $line"; done
      MISSING=0
      for f in config.sh run.sh env.sh bin/installdependencies.sh; do
        if [ -f "$AGENT_DIR/$f" ]; then
          log "  OK: $f exists"
        else
          log "  FAIL: $f NOT FOUND"
          MISSING=1
        fi
      done
      if [ "$MISSING" -eq 1 ]; then
        log "FATAL: Required files missing."
        (find "$AGENT_DIR" -type f || true) | head -50 | while read -r line; do log "    $line"; done
        exit 1
      fi
      log "NOTE: svc.sh will be generated by config.sh (v5.x behavior)"
      log "──── Step 7/9: Installing agent dependencies ────"
      if [ -f "$AGENT_DIR/bin/installdependencies.sh" ]; then
        bash "$AGENT_DIR/bin/installdependencies.sh"
        log "Dependencies installed OK"
      else
        log "WARNING: installdependencies.sh not found, skipping"
      fi
      log "──── Step 8/9: Configuring agent ────"
      chown -R __ADMIN_USER__:__ADMIN_USER__ "$AGENT_DIR"
      log "Ownership set to __ADMIN_USER__"
      log "Running config.sh as __ADMIN_USER__ ..."
      sudo -u __ADMIN_USER__ "$AGENT_DIR/config.sh" --unattended --url "__AZDO_ORG_URL__" --auth pat --token "__AZDO_PAT__" --pool "__AGENT_POOL__" --agent "__AGENT_NAME__" --acceptTeeEula --replace
      if [ $? -ne 0 ]; then
        log "ERROR: config.sh FAILED"
        log "Check: PAT valid? Pool '__AGENT_POOL__' exists? Org URL correct?"
        cat "$AGENT_DIR/_diag/Agent_"*.log 2>/dev/null | tail -30 || true
        exit 1
      fi
      log "Agent configured successfully"
      log "Directory listing after config.sh:"
      ls -la "$AGENT_DIR" | while read -r line; do log "  $line"; done
      log "──── Step 9/9: Installing systemd service ────"
      cd "$AGENT_DIR"
      if [ -f "$AGENT_DIR/svc.sh" ]; then
        log "svc.sh found (generated by config.sh)"
        sudo bash "$AGENT_DIR/svc.sh" install __ADMIN_USER__
        log "Service installed via svc.sh"
        sudo bash "$AGENT_DIR/svc.sh" start
        log "Service started via svc.sh"
        sleep 5
        sudo bash "$AGENT_DIR/svc.sh" status || true
      else
        log "svc.sh NOT found — creating systemd unit manually"
        SVC_UNIT="vsts.agent.__AGENT_NAME__.service"
        UNIT_PATH="/etc/systemd/system/$SVC_UNIT"
        if [ ! -f "$AGENT_DIR/runsvc.sh" ]; then
          cp "$AGENT_DIR/bin/runsvc.sh" "$AGENT_DIR/runsvc.sh" 2>/dev/null || true
          chown __ADMIN_USER__:__ADMIN_USER__ "$AGENT_DIR/runsvc.sh"
          chmod 755 "$AGENT_DIR/runsvc.sh"
        fi
        "$AGENT_DIR/env.sh"
        printf '[Unit]\nDescription=Azure Pipelines Agent (__AGENT_NAME__)\nAfter=network.target\n\n[Service]\nExecStart=%s/runsvc.sh\nUser=__ADMIN_USER__\nWorkingDirectory=%s\nKillMode=process\nKillSignal=SIGTERM\nTimeoutStopSec=5\n\n[Install]\nWantedBy=multi-user.target\n' "$AGENT_DIR" "$AGENT_DIR" > "$UNIT_PATH"
        chmod 664 "$UNIT_PATH"
        systemctl daemon-reload
        systemctl enable "$SVC_UNIT"
        systemctl start "$SVC_UNIT"
        log "Service started via manual systemd unit"
        sleep 5
        systemctl --no-pager status "$SVC_UNIT" || true
      fi
      log "Service status check complete"
      log "=========================================="
      log "Azure DevOps Agent Installation - DONE"
      log "=========================================="
      log "Troubleshooting:"
      log "  tail -f /var/log/azagent-install.log"
      log "  sudo cat /var/log/cloud-init-output.log"
      log "  sudo journalctl -u vsts.agent.* -f"
      log "  cat $AGENT_DIR/_diag/Agent_*.log"

runcmd:
  - /usr/local/bin/install-agent.sh
'''

var cloudInitRendered = replace(
  replace(
    replace(
      replace(
        replace(
          replace(cloudInit, '__ADMIN_USER__', adminUsername),
          '__AZDO_ORG_URL__', azdoOrgUrl),
        '__AZDO_PAT__', azdoPat),
      '__AGENT_POOL__', agentPool),
    '__AGENT_VERSION__', agentVersion),
  '__AGENT_NAME__', agentName)

// ── Network Security Group ──────────────────────────────────────────────────
resource nsg 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: nsgName
  location: location
  tags: tags
  properties: {
    securityRules: [
      {
        name: 'AllowSSH'
        properties: {
          priority: 1000
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '22'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: '*'
        }
      }
    ]
  }
}

// ── Virtual Network ─────────────────────────────────────────────────────────
resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' = {
  name: vnetName
  location: location
  tags: tags
  properties: {
    addressSpace: {
      addressPrefixes: ['10.0.0.0/24']
    }
    subnets: [
      {
        name: subnetName
        properties: {
          addressPrefix: '10.0.0.0/26'
          networkSecurityGroup: { id: nsg.id }
        }
      }
    ]
  }
}

// ── Public IP ───────────────────────────────────────────────────────────────
resource pip 'Microsoft.Network/publicIPAddresses@2024-05-01' = {
  name: pipName
  location: location
  tags: tags
  sku: { name: 'Standard' }
  properties: {
    publicIPAllocationMethod: 'Static'
  }
}

// ── Network Interface ───────────────────────────────────────────────────────
resource nic 'Microsoft.Network/networkInterfaces@2024-05-01' = {
  name: nicName
  location: location
  tags: tags
  properties: {
    ipConfigurations: [
      {
        name: 'ipconfig1'
        properties: {
          privateIPAllocationMethod: 'Dynamic'
          subnet: { id: vnet.properties.subnets[0].id }
          publicIPAddress: { id: pip.id }
        }
      }
    ]
  }
}

// ── Virtual Machine ─────────────────────────────────────────────────────────
resource vm 'Microsoft.Compute/virtualMachines@2024-07-01' = {
  name: vmName
  location: location
  tags: tags
  properties: {
    hardwareProfile: { vmSize: vmSize }
    osProfile: {
      computerName: vmName
      adminUsername: adminUsername
      adminPassword: authenticationType == 'password' ? adminPasswordOrKey : null
      linuxConfiguration: authenticationType == 'sshPublicKey' ? linuxConfiguration : null
      customData: base64(cloudInitRendered)
    }
    storageProfile: {
      imageReference: {
        publisher: 'Canonical'
        offer: '0001-com-ubuntu-server-jammy'
        sku: '22_04-lts-gen2'
        version: 'latest'
      }
      osDisk: {
        createOption: 'FromImage'
        managedDisk: { storageAccountType: 'StandardSSD_LRS' }
        diskSizeGB: 64
      }
    }
    networkProfile: {
      networkInterfaces: [{ id: nic.id }]
    }
  }
}

// ── Outputs ─────────────────────────────────────────────────────────────────
@description('Name of the deployed VM.')
output vmName string = vm.name

@description('Public IP address of the VM.')
output publicIp string = pip.properties.ipAddress

@description('SSH command to connect to the VM.')
output sshCommand string = 'ssh ${adminUsername}@${pip.properties.ipAddress}'
