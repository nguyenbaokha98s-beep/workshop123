// Static Web App module — deploys Microsoft.Web/staticSites into a resource group.

@description('Project name used in resource naming')
param projectName string

@description('Deployment environment')
@allowed(['dev', 'staging', 'prod'])
param environment string

@description('Student name used as suffix for unique resource names in a shared subscription. Leave empty to skip.')
param suffix string = ''

@description('Azure region for the Static Web App')
param location string

@description('SKU tier: Free or Standard')
@allowed(['Free', 'Standard'])
param skuTier string = 'Free'

@description('Optional custom domain (empty = skip)')
param customDomain string = ''

@description('Resource tags')
param tags object = {}

var nameSuffix = !empty(suffix) ? '-${suffix}' : ''
var swaName = '${projectName}-swa-${environment}${nameSuffix}'

resource staticWebApp 'Microsoft.Web/staticSites@2024-11-01' = {
  name: swaName
  location: location
  tags: tags
  sku: {
    name: skuTier
    tier: skuTier
  }
  properties: {
    stagingEnvironmentPolicy: 'Enabled'
    allowConfigFileUpdates: true
    publicNetworkAccess: 'Enabled'
  }
}

resource customDomainBinding 'Microsoft.Web/staticSites/customDomains@2024-04-01' = if (!empty(customDomain)) {
  parent: staticWebApp
  name: customDomain
  properties: {}
}

// Outputs
@description('Static Web App resource ID')
output staticWebAppId string = staticWebApp.id

@description('Default hostname of the Static Web App')
output staticWebAppUrl string = 'https://${staticWebApp.properties.defaultHostname}'

@description('Static Web App name')
output staticWebAppName string = staticWebApp.name
