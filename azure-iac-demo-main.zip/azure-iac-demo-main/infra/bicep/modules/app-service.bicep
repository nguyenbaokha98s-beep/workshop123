// App Service module — deploys an App Service Plan + Web App (API) into a resource group.

@description('Project name used in resource naming')
param projectName string

@description('Deployment environment')
@allowed(['dev', 'staging', 'prod'])
param environment string

@description('Student name used as suffix for unique resource names in a shared subscription. Leave empty to skip.')
param suffix string = ''

@description('Azure region')
param location string

@description('App Service Plan SKU name (e.g. B1, P1v3)')
param skuName string = 'B1'

@description('Linux runtime stack (e.g. DOTNETCORE|8.0, NODE|20-lts, PYTHON|3.11)')
param linuxFxVersion string = 'NODE|20-lts'

@description('Resource tags')
param tags object = {}

var nameSuffix = !empty(suffix) ? '-${suffix}' : ''
var planName = '${projectName}-plan-${environment}${nameSuffix}'
var appName  = '${projectName}-api-${environment}${nameSuffix}'

resource appServicePlan 'Microsoft.Web/serverfarms@2024-04-01' = {
  name: planName
  location: location
  tags: tags
  kind: 'linux'
  sku: {
    name: skuName
  }
  properties: {
    reserved: true // required for Linux
  }
}

resource webApp 'Microsoft.Web/sites@2024-04-01' = {
  name: appName
  location: location
  tags: tags
  kind: 'app,linux'
  properties: {
    serverFarmId: appServicePlan.id
    httpsOnly: true
    siteConfig: {
      linuxFxVersion: linuxFxVersion
      minTlsVersion: '1.2'
      http20Enabled: true
      alwaysOn: skuName != 'F1' && skuName != 'B1' ? true : false
    }
  }
}

// Outputs
@description('App Service resource ID')
output appServiceId string = webApp.id

@description('Default hostname of the Web App')
output appServiceUrl string = 'https://${webApp.properties.defaultHostName}'

@description('Web App name')
output appServiceName string = webApp.name

@description('App Service Plan name')
output appServicePlanName string = appServicePlan.name
