// Subscription-scoped entry point for the Azure DevOps Self-Hosted Agent VM.
// Creates a resource group and deploys the VM via a module.
// Deploy with: az stack sub create (see docs/self-hosted-agent-setup.md)

targetScope = 'subscription'

// ── Parameters ──────────────────────────────────────────────────────────────

@description('Project name used as prefix for all resource names (e.g. agent-build).')
@minLength(2)
@maxLength(30)
param projectName string = 'agent-build'

@description('Student name used as suffix for unique resource names in a shared subscription. Leave empty to skip.')
param suffix string = ''

@description('Azure region for the resource group and VM.')
param location string = 'eastasia'

@description('Admin username for the VM.')
param adminUsername string = 'azureuser'

@secure()
@description('SSH public key or password for the admin user.')
param adminPasswordOrKey string

@allowed(['sshPublicKey', 'password'])
@description('Authentication type: SSH key (recommended) or password.')
param authenticationType string = 'sshPublicKey'

@description('VM size. B2s is sufficient for a build agent.')
param vmSize string = 'Standard_B2s'

@description('Azure DevOps organization URL, e.g. https://dev.azure.com/myorg')
param azdoOrgUrl string

@secure()
@description('Personal Access Token with Agent Pools (Read & manage) scope.')
param azdoPat string

@description('Name of the agent pool in Azure DevOps.')
param agentPool string = 'AzureVMPool'

@description('Name for the agent (visible in Azure DevOps).')
param agentName string = 'agent-vm-01'

@description('Azure Pipelines agent version. Check https://github.com/microsoft/azure-pipelines-agent/releases')
param agentVersion string = '3.248.0'

// ── Resource Group ──────────────────────────────────────────────────────────

var rgSuffix = !empty(suffix) ? '-${suffix}' : ''

resource rg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: '${projectName}-rg${rgSuffix}'
  location: location
  tags: {
    Project: projectName
    Purpose: 'Azure DevOps Self-Hosted Agent'
    ManagedBy: 'Bicep'
  }
}

// ── Module: Agent VM ────────────────────────────────────────────────────────

module agentVm 'modules/agent-vm.bicep' = {
  scope: rg
  params: {
    projectName: projectName
    suffix: suffix
    location: location
    adminUsername: adminUsername
    adminPasswordOrKey: adminPasswordOrKey
    authenticationType: authenticationType
    vmSize: vmSize
    azdoOrgUrl: azdoOrgUrl
    azdoPat: azdoPat
    agentPool: agentPool
    agentName: agentName
    agentVersion: agentVersion
    tags: {
      Project: projectName
      Purpose: 'Azure DevOps Self-Hosted Agent'
      ManagedBy: 'Bicep'
    }
  }
}

// ── Outputs ─────────────────────────────────────────────────────────────────

@description('Resource group name.')
output resourceGroupName string = rg.name

@description('Name of the deployed VM.')
output vmName string = agentVm.outputs.vmName

@description('Public IP address of the VM.')
output publicIp string = agentVm.outputs.publicIp

@description('SSH command to connect to the VM.')
output sshCommand string = agentVm.outputs.sshCommand

@description('Agent pool name in Azure DevOps.')
output agentPool string = agentPool

@description('Agent name in Azure DevOps.')
output agentName string = agentName
