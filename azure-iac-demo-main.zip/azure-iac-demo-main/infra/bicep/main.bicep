// Unified Bicep template — deploys App Service (API) + Static Web App
// into a single resource group under one deployment stack.

targetScope = 'subscription'

// ── Parameters ──────────────────────────────────────────────────────────────

@description('Name of the project (used in resource naming)')
@minLength(2)
@maxLength(20)
param projectName string = 'todo-app-alpha-bicep'

@description('Deployment environment')
@allowed(['dev', 'staging', 'prod'])
param environment string = 'dev'

@description('Student name used as suffix for unique resource names in a shared subscription. Leave empty to skip.')
param suffix string = ''

@description('Azure region for the resource group and App Service')
param location string = 'eastasia'

// App Service params
@description('App Service Plan SKU name (e.g. B1 for dev, P1v3 for prod)')
param skuName string = 'B1'

@description('Linux runtime stack (e.g. DOTNETCORE|8.0, NODE|20-lts, PYTHON|3.11)')
param linuxFxVersion string = 'NODE|20-lts'

// Static Web App params
@description('Azure region for the Static Web App (limited availability)')
param swaLocation string = 'eastasia'

@description('SKU tier for the Static Web App')
@allowed(['Free', 'Standard'])
param skuTier string = 'Free'

@description('Custom domain name (leave empty to skip)')
param customDomain string = ''

// ── Resource Group (single) ─────────────────────────────────────────────────

var rgSuffix = !empty(suffix) ? '-${suffix}' : ''

resource rg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: '${projectName}-rg-${environment}${rgSuffix}'
  location: location
  tags: {
    Project: projectName
    Environment: environment
    ManagedBy: 'Bicep'
    Application: 'Todo Application'
  }
}

// ── Modules ─────────────────────────────────────────────────────────────────

module appService 'modules/app-service.bicep' = {
  scope: rg
  name: 'appServiceDeploy'
  params: {
    projectName: projectName
    environment: environment
    suffix: suffix
    location: location
    skuName: skuName
    linuxFxVersion: linuxFxVersion
    tags: {
      Project: projectName
      Environment: environment
      ManagedBy: 'Bicep'
      Application: 'Web API'
    }
  }
}

module staticWebApp 'modules/static-web-app.bicep' = {
  scope: rg
  name: 'staticWebAppDeploy'
  params: {
    projectName: projectName
    environment: environment
    suffix: suffix
    location: swaLocation
    skuTier: skuTier
    customDomain: customDomain
    tags: {
      Project: projectName
      Environment: environment
      ManagedBy: 'Bicep'
      Application: 'Todo Frontend'
    }
  }
}

// ── Outputs ─────────────────────────────────────────────────────────────────

@description('Resource group name')
output resourceGroupName string = rg.name

@description('App Service name')
output appServiceName string = appService.outputs.appServiceName

@description('App Service default URL')
output appServiceUrl string = appService.outputs.appServiceUrl

@description('Static Web App name')
output staticWebAppName string = staticWebApp.outputs.staticWebAppName

@description('Static Web App default hostname')
output staticWebAppUrl string = staticWebApp.outputs.staticWebAppUrl
