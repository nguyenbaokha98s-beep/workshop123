<#
.SYNOPSIS
    Lists available Azure VM SKUs filtered by location and size prefix.

.DESCRIPTION
    Uses Azure CLI to query VM SKUs that are available in a given location
    and match a size prefix (e.g. "Standard_B"). Excludes restricted SKUs.

.PARAMETER Location
    Azure region to query (e.g. "eastasia", "eastus").

.PARAMETER SizePrefix
    VM size prefix to filter by (e.g. "Standard_B", "Standard_D").

.EXAMPLE
    .\list-vm-skus.ps1
    .\list-vm-skus.ps1 -Location "eastus" -SizePrefix "Standard_D"
#>

param(
    [string]$Location = "eastasia",
    [string]$SizePrefix = "Standard_B"
)

Write-Host "`n=== Azure VM SKUs ===" -ForegroundColor Cyan
Write-Host "Location    : $Location"
Write-Host "Size Prefix : $SizePrefix"
Write-Host "==============================`n" -ForegroundColor Cyan

# Step 1: Get all VM SKUs for the location and size prefix as JSON
$json = az vm list-skus `
    --location $Location `
    --size $SizePrefix `
    --resource-type virtualMachines `
    --output json 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "`nError: Failed to list VM SKUs. Make sure you are logged in (az login)." -ForegroundColor Red
    Write-Host $json
    exit 1
}

# Step 2: Parse and filter SKUs, then display as a table
$skus = $json | ConvertFrom-Json

$results = $skus | ForEach-Object {
    # Check for location-level restriction (fully blocked for the entire region)
    $locationRestriction = $_.restrictions | Where-Object {
        $_.reasonCode -eq "NotAvailableForSubscription" -and $_.type -eq "Location"
    }

    # If the SKU is fully blocked at the location level, skip it
    if ($locationRestriction) { return }

    # Check for zone-level restrictions
    $zoneRestriction = $_.restrictions | Where-Object {
        $_.reasonCode -eq "NotAvailableForSubscription" -and $_.type -eq "Zone"
    }
    $restrictedZones = @()
    if ($zoneRestriction) {
        $restrictedZones = $zoneRestriction.restrictionInfo.zones
    }

    $allZones = if ($_.locationInfo.zones) { $_.locationInfo[0].zones } else { @() }
    $availableZones = $allZones | Where-Object { $_ -notin $restrictedZones }

    $caps = $_.capabilities
    [PSCustomObject]@{
        Name            = $_.name
        Tier            = $_.tier
        vCPUs           = ($caps | Where-Object { $_.name -eq "vCPUs" }).value
        "Memory(GB)"    = ($caps | Where-Object { $_.name -eq "MemoryGB" }).value
        MaxDataDisks    = ($caps | Where-Object { $_.name -eq "MaxDataDiskCount" }).value
        AvailableZones  = if ($availableZones) { $availableZones -join "," } else { "N/A (no zonal)" }
        RestrictedZones = if ($restrictedZones) { $restrictedZones -join "," } else { "-" }
    }
}

if (-not $results -or $results.Count -eq 0) {
    Write-Host "No VM SKUs found for prefix '$SizePrefix' in '$Location'." -ForegroundColor Yellow
} else {
    Write-Host "Found $($results.Count) SKU(s):`n" -ForegroundColor Green
    $results | Sort-Object Name | Format-Table -AutoSize
}

Write-Host "`nDone." -ForegroundColor Green
