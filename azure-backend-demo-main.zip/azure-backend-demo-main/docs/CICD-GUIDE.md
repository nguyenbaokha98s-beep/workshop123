# CI/CD Pipeline Guide

## Architecture: GitHub Actions (CI) → Azure Pipelines (CD)

This project splits CI and CD across two platforms:

- **GitHub Actions** — Continuous Integration (build & test)
- **Azure Pipelines** — Continuous Deployment (deploy to Azure App Service with manual approval)

---

## Pipeline Flow

```mermaid
flowchart TD
    DEV_PUSH([Developer pushes to main]) --> GHA

    subgraph GHA["GitHub Actions CI (.github/workflows/ci.yml)"]
        direction TB
        G1[1. Checkout code] --> G2[2. Setup Node.js 20]
        G2 --> G3[3. npm ci]
        G3 --> G4[4. npm run lint]
        G4 --> G5[5. npm test]
        G5 --> G6[6. Azure/pipelines@v1\ntrigger CD pipeline]
    end

    GHA --> AZP

    subgraph AZP["Azure Pipelines CD (pipelines/azure-pipelines.yml)"]
        direction TB
        S1["Stage 1 — Validate\nDisplay commit SHA & actor info"]
        S1 --> APPROVAL_DEV

        APPROVAL_DEV{{"🔒 Manual Approval\n(dev environment)"}}
        APPROVAL_DEV --> S2

        subgraph S2["Stage 2 — Deploy → DEV"]
            direction TB
            D1[Checkout source code] --> D2[npm ci --omit=dev]
            D2 --> D3[Create deployment zip]
            D3 --> D4[Deploy to DEV App Service]
            D4 --> D5[Health check]
        end

        S2 --> APPROVAL_PROD

        APPROVAL_PROD{{"🔒 Manual Approval\n(prod environment)"}}
        APPROVAL_PROD --> S3

        subgraph S3["Stage 3 — Deploy → PROD"]
            direction TB
            P1[Checkout source code] --> P2[npm ci --omit=dev]
            P2 --> P3[Create deployment zip]
            P3 --> P4[Deploy to PROD App Service]
            P4 --> P5[Health check]
        end
    end

    PR([Pull Request to main]) -->|CI only — no CD trigger| GHA
```

### What happens on a Pull Request?

- GitHub Actions CI runs **build & test only** (no CD trigger)
- The `trigger-cd` job is skipped because it only runs on `push` to `main`

### What happens on push to main?

1. GitHub Actions runs build & test
2. If build & test pass → GitHub Actions calls the Azure DevOps REST API
3. Azure Pipelines CD starts → shows build info in the Validate stage
4. Pipeline **pauses** and waits for manual approval on the `dev` environment
5. Approver reviews the commit info and approves
6. DEV deployment runs → health check
7. Pipeline **pauses** again and waits for approval on the `prod` environment
8. Approver approves → PROD deployment runs → health check

---

## Setup Guide

### Prerequisites

- A GitHub repository (this repo: `jacintobernier1996/azure-backend-demo`)
- An Azure DevOps organization and project
- Azure App Services created for DEV and PROD
- An Azure subscription with App Service deployed

---

### Step 1: Set Up Azure DevOps

#### 1.1 Create a GitHub Service Connection

1. Go to **Azure DevOps** → Your Project → **Project Settings** (bottom-left gear icon)
2. Click **Service connections** → **New service connection**
3. Select **GitHub** → **Next**
4. Choose **Grant authorization (OAuth)** or **Personal Access Token**
5. Name it (e.g. `github-service-connection`) → **Save**

#### 1.2 Create an ARM Service Connection

1. Go to **Project Settings** → **Service connections** → **New service connection**
2. Select **Azure Resource Manager** → **Next**
3. Choose **Service principal (automatic)** (recommended)
4. Select your Azure subscription and resource group
5. Name it (e.g. `azure-subscription`) → **Save**

#### 1.3 Create Environments with Approval Gates

1. Go to **Pipelines** → **Environments** → **New environment**
2. Create environment named **`dev`**
   - Click on the `dev` environment → click **⋮** (three dots) → **Approvals and checks**
   - Click **+** → **Approvals**
   - Add the user(s) or group(s) who can approve DEV deployments
   - Click **Create**
3. Create environment named **`prod`**
   - Same steps: add approvers for PROD deployments
   - (Optionally add a different/stricter set of approvers for production)

#### 1.4 Create a Variable Group

1. Go to **Pipelines** → **Library** → **+ Variable group**
2. Name it **`azure-backend-demo-vars`**
3. Add the following variables:

| Variable Name | Value | Example |
|---|---|---|
| `azure-subscription` | Name of the ARM Service Connection | `azure-subscription` |
| `app-service-name-dev` | Azure App Service name for DEV | `my-backend-dev` |
| `app-service-name-prod` | Azure App Service name for PROD | `my-backend-prod` |

4. Click **Save**

#### 1.5 Create the Pipeline

1. Go to **Pipelines** → **New pipeline**
2. Select **GitHub** as the source
3. Select the repository `jacintobernier1996/azure-backend-demo`
4. Choose **Existing Azure Pipelines YAML file**
5. Select branch: `main`, path: **`/pipelines/azure-pipelines.yml`**
6. Click **Run** (or **Save** without running)
7. **Note the Pipeline Name** — this is the name shown in the Azure DevOps UI (e.g. `azure-backend-demo`). You'll need it for the `AZURE_PIPELINE_NAME` GitHub secret.

---

### Step 2: Set Up GitHub Secrets

Go to your GitHub repository → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**

Add the following secrets:

| Secret Name | Value | How to get it |
|---|---|---|
| `AZURE_DEVOPS_PAT` | Azure DevOps Personal Access Token | See [Step 2.1](#21-create-an-azure-devops-pat) below |
| `AZURE_DEVOPS_ORG` | Azure DevOps organization name | The `{org}` part of `https://dev.azure.com/{org}/` |
| `AZURE_DEVOPS_PROJECT` | Azure DevOps project name | The `{project}` part of `https://dev.azure.com/{org}/{project}/` |
| `AZURE_PIPELINE_NAME` | Pipeline name as shown in Azure DevOps UI | The name from Step 1.5 (e.g. `azure-backend-demo`) |

#### 2.1 Create an Azure DevOps PAT

1. Go to **Azure DevOps** → click your profile icon (top-right) → **Personal access tokens**
2. Click **+ New Token**
3. Configure:
   - **Name**: `github-ci-trigger` (or any name)
   - **Organization**: Select your organization
   - **Expiration**: Set a reasonable expiration (e.g. 1 year)
   - **Scopes**: Select **Custom defined**, then check:
     - **Build** → **Read & execute**
4. Click **Create** → **Copy the token immediately** (you won't see it again)
5. Paste it as the `AZURE_DEVOPS_PAT` secret in GitHub

---

### Step 3: Disable the Old Workflow

The old workflow `deploy-webapp.yml` did both CI and CD in GitHub Actions. It should be disabled:

1. Go to your GitHub repository → **Actions**
2. Click on **Deploy Web App** (left sidebar)
3. Click **⋯** (three dots) → **Disable workflow**

Alternatively, delete the file `.github/workflows/deploy-webapp.yml`.

---

## File Structure

```
azure-backend-demo/
├── .github/
│   └── workflows/
│       ├── ci.yml                  ← GitHub Actions CI (build + test + trigger CD)
│       └── deploy-webapp.yml       ← OLD workflow (disable or delete)
├── pipelines/
│   └── azure-pipelines.yml        ← Azure Pipelines CD (deploy with approval)
├── server.js
├── package.json
├── Dockerfile
└── db.json
```

---

## How to Approve a Deployment

When GitHub CI triggers the Azure Pipelines CD:

1. You will receive an **email notification** from Azure DevOps (if configured)
2. Or go to **Azure DevOps** → **Pipelines** → find the running pipeline
3. You'll see the pipeline paused at the **Deploy → DEV** stage with a message:
   ```
   ⏸ Review  |  1 approval needed
   ```
4. Click **Review** → you'll see the commit SHA and who triggered it
5. Click **Approve** to continue the deployment to DEV
6. After DEV succeeds, the pipeline pauses again at **Deploy → PROD**
7. Click **Review** → **Approve** to deploy to PROD

### Rejecting a Deployment

- Click **Review** → **Reject** to cancel the deployment
- The pipeline will stop and no deployment will occur

---

## Troubleshooting

### CI passes but CD is not triggered

1. Check the `trigger-cd` job logs in GitHub Actions
2. Verify all 4 GitHub secrets are set correctly:
   - `AZURE_DEVOPS_PAT` — must not be expired
   - `AZURE_DEVOPS_ORG` — org name only, not the full URL
   - `AZURE_DEVOPS_PROJECT` — project name only
   - `AZURE_PIPELINE_NAME` — pipeline name as shown in Azure DevOps UI (not a numeric ID)
3. Check the PAT has **Build → Read & execute** scope

### Azure Pipeline fails at checkout

- Ensure the GitHub Service Connection is configured in Azure DevOps
- The pipeline needs permission to access the GitHub repository

### Azure Pipeline fails at deploy

- Verify the ARM Service Connection has access to the App Service
- Check the variable group `azure-backend-demo-vars` has the correct values
- Ensure the App Service names match exactly

### Approval timeout

- By default, Azure DevOps approvals time out after **30 days**
- You can configure the timeout in the environment's approval settings
- If timed out, re-run the pipeline from Azure DevOps or push a new commit

---

## Security Notes

| Concern | How it's handled |
|---|---|
| Azure DevOps PAT in GitHub | Stored as an encrypted GitHub Secret — never exposed in logs |
| PAT scope | Minimal scope: only `Build → Read & execute` |
| ARM credentials | Managed by Azure DevOps Service Connection — never stored in code |
| Manual approval | Both DEV and PROD require human approval before deployment |
| PR builds | Pull requests only run CI (build + test) — no CD trigger |
| Concurrency | GitHub Actions cancels in-progress runs for the same branch |
