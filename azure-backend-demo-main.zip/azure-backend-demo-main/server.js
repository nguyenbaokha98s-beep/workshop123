const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3001;
const DB_PATH = path.join(__dirname, 'db.json');

const allowedOrigins = process.env.CORS_ORIGIN
  ? process.env.CORS_ORIGIN.split(',')
  : ['http://localhost:5173'];

app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin) || /^https?:\/\/[^.]+\.azurestaticapps\.net$/.test(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
}));
app.use(express.json());

function readDb() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ todos: [] }, null, 2));
  }
  const data = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(data);
}

function writeDb(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// Health check
app.get('/health', (_req, res) => {
  res.status(200).json({ status: 'ok' });
});

// GET all todos
app.get('/api/todos', (_req, res) => {
  const db = readDb();
  res.json(db.todos);
});

// GET single todo
app.get('/api/todos/:id', (req, res) => {
  const db = readDb();
  const todo = db.todos.find((t) => t.id === req.params.id);
  if (!todo) {
    return res.status(404).json({ error: 'Todo not found' });
  }
  res.json(todo);
});

// POST create todo
app.post('/api/todos', (req, res) => {
  const { name, description, startTime, deadline } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Name is required' });
  }

  const db = readDb();
  const newTodo = {
    id: uuidv4(),
    name,
    description: description || '',
    startTime: startTime || null,
    deadline: deadline || null,
    createdAt: new Date().toISOString(),
  };
  db.todos.push(newTodo);
  writeDb(db);
  res.status(201).json(newTodo);
});

// PUT update todo
app.put('/api/todos/:id', (req, res) => {
  const db = readDb();
  const index = db.todos.findIndex((t) => t.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Todo not found' });
  }

  const { name, description, startTime, deadline } = req.body;
  db.todos[index] = {
    ...db.todos[index],
    name: name !== undefined ? name : db.todos[index].name,
    description: description !== undefined ? description : db.todos[index].description,
    startTime: startTime !== undefined ? startTime : db.todos[index].startTime,
    deadline: deadline !== undefined ? deadline : db.todos[index].deadline,
  };
  writeDb(db);
  res.json(db.todos[index]);
});

// DELETE todo
app.delete('/api/todos/:id', (req, res) => {
  const db = readDb();
  const index = db.todos.findIndex((t) => t.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Todo not found' });
  }
  const deleted = db.todos.splice(index, 1)[0];
  writeDb(db);
  res.json(deleted);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
