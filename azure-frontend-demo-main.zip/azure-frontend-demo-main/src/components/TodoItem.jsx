function formatDate(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleString();
}

export default function TodoItem({ todo, onView, onEdit, onDelete }) {
  const isPastDeadline = todo.deadline && new Date(todo.deadline) < new Date();

  return (
    <div className="bg-white rounded-lg shadow p-4 flex flex-col gap-2">
      <div className="flex items-start justify-between">
        <h3 className="text-lg font-semibold text-gray-900">{todo.name}</h3>
        {isPastDeadline && (
          <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full">
            Overdue
          </span>
        )}
      </div>

      {todo.description && (
        <p className="text-gray-600 text-sm line-clamp-2">{todo.description}</p>
      )}

      <div className="text-xs text-gray-500 mt-1 space-y-0.5">
        <div>Start: {formatDate(todo.startTime)}</div>
        <div>Deadline: {formatDate(todo.deadline)}</div>
      </div>

      <div className="flex gap-2 mt-2 pt-2 border-t border-gray-100">
        <button
          onClick={() => onView(todo)}
          className="text-sm text-blue-600 hover:text-blue-800 cursor-pointer"
        >
          View
        </button>
        <button
          onClick={() => onEdit(todo)}
          className="text-sm text-amber-600 hover:text-amber-800 cursor-pointer"
        >
          Edit
        </button>
        <button
          onClick={() => onDelete(todo)}
          className="text-sm text-red-600 hover:text-red-800 cursor-pointer"
        >
          Delete
        </button>
      </div>
    </div>
  );
}
