function formatDate(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleString();
}

export default function TodoDetail({ todo, onClose, onEdit }) {
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 max-w-lg w-full mx-4">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">{todo.name}</h2>

        <div className="space-y-3 mb-6">
          <div>
            <span className="text-sm font-medium text-gray-500">Description</span>
            <p className="text-gray-800 mt-0.5">
              {todo.description || 'No description'}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="text-sm font-medium text-gray-500">Start Time</span>
              <p className="text-gray-800 mt-0.5">{formatDate(todo.startTime)}</p>
            </div>
            <div>
              <span className="text-sm font-medium text-gray-500">Deadline</span>
              <p className="text-gray-800 mt-0.5">{formatDate(todo.deadline)}</p>
            </div>
          </div>

          <div>
            <span className="text-sm font-medium text-gray-500">Created At</span>
            <p className="text-gray-800 mt-0.5">{formatDate(todo.createdAt)}</p>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => onEdit(todo)}
            className="bg-amber-500 text-white px-4 py-2 rounded-md hover:bg-amber-600 transition-colors cursor-pointer"
          >
            Edit
          </button>
          <button
            onClick={onClose}
            className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-300 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
