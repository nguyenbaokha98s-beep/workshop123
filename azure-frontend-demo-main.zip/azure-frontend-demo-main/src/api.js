import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api/todos';

export async function fetchTodos() {
  const res = await axios.get(API_URL);
  return res.data;
}

export async function fetchTodo(id) {
  const res = await axios.get(`${API_URL}/${id}`);
  return res.data;
}

export async function createTodo(todo) {
  const res = await axios.post(API_URL, todo);
  return res.data;
}

export async function updateTodo(id, todo) {
  const res = await axios.put(`${API_URL}/${id}`, todo);
  return res.data;
}

export async function deleteTodo(id) {
  const res = await axios.delete(`${API_URL}/${id}`);
  return res.data;
}
