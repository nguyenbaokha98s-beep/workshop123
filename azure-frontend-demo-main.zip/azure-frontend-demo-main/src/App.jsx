import { useState, useEffect } from 'react';
import { fetchTodos, createTodo, updateTodo, deleteTodo } from './api';
import TodoList from './components/TodoList';
import TodoForm from './components/TodoForm';
import TodoDetail from './components/TodoDetail';

function App() {
  const [todos, setTodos] = useState([]);
  const [view, setView] = useState('list'); // 'list' | 'create' | 'edit'
  const [selectedTodo, setSelectedTodo] = useState(null);
  const [detailTodo, setDetailTodo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadTodos();
  }, []);

  async function loadTodos() {
    try {
      setLoading(true);
      const data = await fetchTodos();
      setTodos(data);
      setError(null);
    } catch {
      setError('Failed to load todos. Is the backend running?');
    } finally {
      setLoading(false);
    }
  }

  async function handleCreate(todoData) {
    try {
      await createTodo(todoData);
      await loadTodos();
      setView('list');
    } catch {
      setError('Failed to create todo.');
    }
  }

  async function handleUpdate(todoData) {
    try {
      await updateTodo(selectedTodo.id, todoData);
      await loadTodos();
      setView('list');
      setSelectedTodo(null);
    } catch {
      setError('Failed to update todo.');
    }
  }

  async function handleDelete(todo) {
    if (!window.confirm(`Delete "${todo.name}"?`)) return;
    try {
      await deleteTodo(todo.id);
      await loadTodos();
      if (detailTodo?.id === todo.id) setDetailTodo(null);
    } catch {
      setError('Failed to delete todo.');
    }
  }

  function handleView(todo) {
    setDetailTodo(todo);
  }

  function handleEdit(todo) {
    setSelectedTodo(todo);
    setDetailTodo(null);
    setView('edit');
  }

  function handleCancelForm() {
    setView('list');
    setSelectedTodo(null);
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">Todo App</h1>
          {view === 'list' && (
            <button
              onClick={() => setView('create')}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors cursor-pointer"
            >
              + New Todo 1
            </button>
          )}
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md mb-4">
            {error}
            <button
              onClick={() => setError(null)}
              className="ml-3 underline text-sm cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {view === 'create' && (
          <TodoForm onSubmit={handleCreate} onCancel={handleCancelForm} />
        )}

        {view === 'edit' && selectedTodo && (
          <TodoForm
            onSubmit={handleUpdate}
            initialData={selectedTodo}
            onCancel={handleCancelForm}
          />
        )}

        {loading ? (
          <div className="text-center py-12 text-gray-500">Loading...</div>
        ) : (
          <TodoList
            todos={todos}
            onView={handleView}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        )}

        {detailTodo && (
          <TodoDetail
            todo={detailTodo}
            onClose={() => setDetailTodo(null)}
            onEdit={handleEdit}
          />
        )}
      </main>
    </div>
  );
}

export default App;
