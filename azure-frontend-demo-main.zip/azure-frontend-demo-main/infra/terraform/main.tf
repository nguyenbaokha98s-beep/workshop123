# =============================================================================
# Azure Static Web App - Terraform Configuration
# =============================================================================
# This Terraform configuration provisions an Azure Static Web App for hosting
# the React + Vite Todo application with GitHub Actions CI/CD integration.
# =============================================================================

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }

  # Remote backend for state management (recommended for teams)
  # Uncomment and configure for your Azure Storage Account:
  # backend "azurerm" {
  #   resource_group_name  = "tfstate-rg"
  #   storage_account_name = "tfstatetodoapp"
  #   container_name       = "tfstate"
  #   key                  = "todo-frontend.tfstate"
  # }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

# =============================================================================
# Resource Group
# =============================================================================
resource "azurerm_resource_group" "main" {
  name     = "${var.project_name}-${var.environment}-rg"
  location = var.location

  tags = local.common_tags
}

# =============================================================================
# Azure Static Web App
# =============================================================================
resource "azurerm_static_web_app" "main" {
  name                = "${var.project_name}-${var.environment}-swa"
  resource_group_name = azurerm_resource_group.main.name
  location            = var.swa_location
  sku_tier            = var.sku_tier
  sku_size            = var.sku_tier

  tags = local.common_tags
}

# =============================================================================
# Custom Domain (Optional)
# =============================================================================
resource "azurerm_static_web_app_custom_domain" "main" {
  count = var.custom_domain != "" ? 1 : 0

  static_web_app_id = azurerm_static_web_app.main.id
  domain_name       = var.custom_domain
  validation_type   = "cname-delegation"
}

# =============================================================================
# Local Values
# =============================================================================
locals {
  common_tags = {
    Project     = var.project_name
    Environment = var.environment
    ManagedBy   = "Terraform"
    Application = "Todo Frontend"
  }
}
