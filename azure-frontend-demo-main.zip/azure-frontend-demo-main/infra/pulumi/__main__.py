"""
Azure Static Web App - Pulumi Configuration (Python)
=====================================================
This Pulumi program provisions an Azure Static Web App for hosting
the React + Vite Todo application with GitHub Actions CI/CD integration.
"""

import pulumi
from pulumi_azure_native import resources, web

# =============================================================================
# Configuration
# =============================================================================

config = pulumi.Config()
project_name = config.get("projectName") or "todo-app"
environment = config.get("environment") or "dev"
location = config.get("location") or "eastus2"
swa_location = config.get("swaLocation") or "eastus2"
sku_tier = config.get("skuTier") or "Free"
custom_domain = config.get("customDomain") or ""

# Common tags
common_tags = {
    "Project": project_name,
    "Environment": environment,
    "ManagedBy": "Pulumi",
    "Application": "Todo Frontend",
}

# =============================================================================
# Resource Group
# =============================================================================

resource_group = resources.ResourceGroup(
    f"{project_name}-{environment}-rg",
    resource_group_name=f"{project_name}-{environment}-rg",
    location=location,
    tags=common_tags,
)

# =============================================================================
# Azure Static Web App
# =============================================================================

static_web_app = web.StaticSite(
    f"{project_name}-{environment}-swa",
    name=f"{project_name}-{environment}-swa",
    resource_group_name=resource_group.name,
    location=swa_location,
    sku=web.SkuDescriptionArgs(
        name=sku_tier,
        tier=sku_tier,
    ),
    staging_environment_policy=web.StagingEnvironmentPolicy.ENABLED,
    allow_config_file_updates=True,
    build_properties=web.StaticSiteBuildPropertiesArgs(
        app_location="/",
        output_location="dist",
    ),
    tags=common_tags,
)

# =============================================================================
# Custom Domain (Optional)
# =============================================================================

if custom_domain:
    custom_domain_resource = web.StaticSiteCustomDomain(
        f"{project_name}-{environment}-domain",
        name=custom_domain,
        static_site_name=static_web_app.name,
        resource_group_name=resource_group.name,
        validation_method="cname-delegation",
    )

# =============================================================================
# Outputs
# =============================================================================

pulumi.export("staticWebAppId", static_web_app.id)
pulumi.export("staticWebAppUrl", static_web_app.default_hostname.apply(
    lambda hostname: f"https://{hostname}"
))
pulumi.export("staticWebAppName", static_web_app.name)
pulumi.export("resourceGroupName", resource_group.name)

# Export the deployment token (sensitive)
api_key = pulumi.Output.all(resource_group.name, static_web_app.name).apply(
    lambda args: web.list_static_site_secrets(
        resource_group_name=args[0],
        name=args[1],
    )
).apply(lambda secrets: secrets.properties.get("apiKey", ""))

pulumi.export("deploymentToken", pulumi.Output.secret(api_key))
