// =============================================================================
// Static Web App Module
// =============================================================================

@description('Name of the project')
param projectName string

@description('Deployment environment')
param environment string

@description('Azure region for the Static Web App')
param location string

@description('SKU tier')
param skuTier string

@description('Custom domain name')
param customDomain string

@description('Resource tags')
param tags object

// =============================================================================
// Static Web App Resource
// =============================================================================

resource staticWebApp 'Microsoft.Web/staticSites@2024-04-01' = {
  name: '${projectName}-${environment}-swa'
  location: location
  tags: tags
  sku: {
    name: skuTier
    tier: skuTier
  }
  properties: {
    stagingEnvironmentPolicy: 'Enabled'
    allowConfigFileUpdates: true
    buildProperties: {
      appLocation: '/'
      outputLocation: 'dist'
    }
  }
}

// =============================================================================
// Custom Domain (Conditional)
// =============================================================================

resource customDomainResource 'Microsoft.Web/staticSites/customDomains@2024-04-01' = if (customDomain != '') {
  parent: staticWebApp
  name: customDomain
  properties: {
    validationMethod: 'cname-delegation'
  }
}

// =============================================================================
// Outputs
// =============================================================================

@description('The ID of the Static Web App')
output staticWebAppId string = staticWebApp.id

@description('The default URL of the Static Web App')
output staticWebAppUrl string = 'https://${staticWebApp.properties.defaultHostname}'

@description('The name of the Static Web App')
output staticWebAppName string = staticWebApp.name
