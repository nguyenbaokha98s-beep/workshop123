// =============================================================================
// Azure Static Web App - Bicep Configuration
// =============================================================================
// This Bicep template provisions an Azure Static Web App for hosting
// the React + Vite Todo application with GitHub Actions CI/CD integration.
// =============================================================================

targetScope = 'subscription'

// =============================================================================
// Parameters
// =============================================================================

@description('Name of the project (used in resource naming)')
@minLength(2)
@maxLength(20)
param projectName string = 'todo-app-bicep'

@description('Deployment environment')
@allowed([
  'dev'
  'staging'
  'prod'
])
param environment string = 'dev'

@description('Azure region for the resource group')
param location string = 'southeastasia'

@description('Azure region for the Static Web App (limited availability)')
param swaLocation string = 'southeastasia'

@description('SKU tier for the Static Web App')
@allowed([
  'Free'
  'Standard'
])
param skuTier string = 'Free'

@description('Custom domain name (leave empty to skip)')
param customDomain string = ''

// =============================================================================
// Resource Group
// =============================================================================

resource resourceGroup 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: '${projectName}-${environment}-rg'
  location: location
  tags: {
    Project: projectName
    Environment: environment
    ManagedBy: 'Bicep'
    Application: 'Todo Frontend'
  }
}

// =============================================================================
// Static Web App Module
// =============================================================================

module staticWebApp 'modules/static-web-app.bicep' = {
  name: 'staticWebAppDeployment'
  scope: resourceGroup
  params: {
    projectName: projectName
    environment: environment
    location: swaLocation
    skuTier: skuTier
    customDomain: customDomain
    tags: {
      Project: projectName
      Environment: environment
      ManagedBy: 'Bicep'
      Application: 'Todo Frontend'
    }
  }
}

// =============================================================================
// Outputs
// =============================================================================

@description('The ID of the Static Web App')
output staticWebAppId string = staticWebApp.outputs.staticWebAppId

@description('The default hostname of the Static Web App')
output staticWebAppUrl string = staticWebApp.outputs.staticWebAppUrl

@description('The name of the resource group')
output resourceGroupName string = resourceGroup.name

@description('The name of the Static Web App')
output staticWebAppName string = staticWebApp.outputs.staticWebAppName

@description('The API key for the Static Web App (use az CLI to retrieve)')
output deploymentTokenCommand string = 'az staticwebapp secrets list --name ${staticWebApp.outputs.staticWebAppName} --query "properties.apiKey" -o tsv'
