# Infrastructure as Code (IaC) - Azure Deployment Guide

This document provides a comprehensive comparison and implementation guide for deploying the **Todo App** (React + Vite) to **Azure Static Web Apps** using three leading IaC solutions.

---

## Table of Contents

- [Project Overview](#project-overview)
- [Architecture Diagram](#architecture-diagram)
- [IaC Solutions Comparison](#iac-solutions-comparison)
  - [Quick Comparison Matrix](#quick-comparison-matrix)
  - [1. Terraform](#1-terraform)
  - [2. Bicep](#2-bicep)
  - [3. Pulumi](#3-pulumi)
- [Detailed Feature Comparison](#detailed-feature-comparison)
- [Recommendation](#recommendation)
- [Getting Started](#getting-started)
- [Prerequisites](#prerequisites)
- [Deployment Instructions](#deployment-instructions)
- [CI/CD Workflows](#cicd-workflows)
- [Cost Estimates](#cost-estimates)

---

## Project Overview

| Property          | Value                              |
| ----------------- | ---------------------------------- |
| **App Type**      | React 19 + Vite 7 SPA             |
| **Styling**       | Tailwind CSS 4                     |
| **Build Output**  | Static files in `dist/`            |
| **API Backend**   | External REST API (configurable)   |
| **Azure Service** | Azure Static Web Apps              |
| **CI/CD**         | GitHub Actions                     |

## Architecture Diagram

```
                    GitHub Repository
                          |
                  GitHub Actions CI/CD
                    /           \
           IaC Provisioning    App Build (npm)
           (TF/Bicep/Pulumi)      |
                  |             dist/
                  v               |
          Azure Resource Group    |
                  |               v
          Azure Static Web App <--'
                  |
           Custom Domain (optional)
                  |
              End Users
```

---

## IaC Solutions Comparison

### Quick Comparison Matrix

| Criteria                    | Terraform                | Bicep                   | Pulumi                  |
| --------------------------- | ------------------------ | ----------------------- | ----------------------- |
| **Language**                | HCL (Domain-Specific)   | Bicep DSL               | Python/TS/Go/C#         |
| **Provider**                | HashiCorp (3rd party)   | Microsoft (1st party)   | Pulumi (3rd party)      |
| **Multi-Cloud**             | Yes                     | No (Azure only)         | Yes                     |
| **State Management**        | Remote backend needed   | Built into Azure        | Pulumi Cloud / self-hosted |
| **Learning Curve**          | Medium                  | Low (Azure devs)        | Low (if you know Python/TS) |
| **Preview/Plan**            | `terraform plan`        | `az what-if`            | `pulumi preview`        |
| **Destroy Support**         | `terraform destroy`     | Manual / az CLI          | `pulumi destroy`        |
| **Azure Day-0 Support**     | Slight delay            | Immediate               | Slight delay            |
| **IDE Support**             | Excellent               | Excellent (VS Code)     | Excellent               |
| **Community Size**          | Very Large              | Growing (Azure-focused) | Growing                 |
| **Cost**                    | Free (OSS) / Paid Cloud | Free                    | Free (OSS) / Paid Cloud |
| **Drift Detection**         | Yes (state-based)       | Limited                 | Yes (state-based)       |
| **Secret Management**       | Via state encryption    | Azure Key Vault         | Built-in encryption     |
| **Files in this project**   | 4 files                 | 4 files + 1 module      | 4 files                 |
| **Lines of Code**           | ~120                    | ~140                    | ~90                     |

---

### 1. Terraform

**Directory:** `infra/terraform/`

#### Pros
- **Industry standard** - Most widely adopted IaC tool with the largest community
- **Multi-cloud** - Same language (HCL) works with AWS, GCP, Azure, and 3000+ providers
- **Mature ecosystem** - Extensive module registry, well-documented, battle-tested
- **State management** - Robust state tracking enables drift detection and safe updates
- **`terraform plan`** - Clear execution plan before any changes are applied
- **Import existing resources** - Can adopt already-deployed infrastructure into management
- **Team collaboration** - Terraform Cloud/Enterprise provides workspaces, RBAC, and policy as code

#### Cons
- **HCL learning curve** - Requires learning a domain-specific language
- **State file management** - Must configure remote state backend (Azure Storage, S3, Terraform Cloud)
- **Azure feature lag** - New Azure features may take days/weeks to appear in the AzureRM provider
- **BSL license** - HashiCorp changed from open source to Business Source License (OpenTofu exists as fork)
- **No loops/conditionals natively** - `count`/`for_each` are workarounds, not true programming constructs

#### Key Files
```
infra/terraform/
  main.tf                    # Core resources (RG + Static Web App)
  variables.tf               # Input variable definitions with validation
  outputs.tf                 # Output values (URL, API key, etc.)
  terraform.tfvars.example   # Example variable values
```

#### Quick Start
```bash
cd infra/terraform
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your subscription ID

terraform init
terraform plan
terraform apply
```

---

### 2. Bicep

**Directory:** `infra/bicep/`

#### Pros
- **Azure-native** - First-party Microsoft tool, always up to date with Azure APIs
- **Zero-day support** - New Azure services available in Bicep on the day they launch
- **No state file** - Uses Azure Resource Manager's built-in state; nothing extra to manage
- **Familiar syntax** - Cleaner than ARM templates, concise and readable
- **What-If analysis** - Built-in preview (`az deployment what-if`) before deployment
- **Free forever** - No licensing concerns, fully open source by Microsoft
- **VS Code extension** - Excellent IntelliSense, validation, and auto-completion
- **Decompile ARM** - Can convert existing ARM templates to Bicep automatically

#### Cons
- **Azure-only** - Cannot manage AWS, GCP, or non-Azure resources
- **Limited destroy** - No native `destroy` command; must delete resource groups via Azure CLI
- **No drift detection** - Cannot detect manual changes made outside of Bicep
- **Imperative gaps** - Complex logic (loops, conditionals) is more limited than Terraform/Pulumi
- **Module ecosystem** - Smaller module registry compared to Terraform
- **No state tracking** - Harder to track what was deployed and manage dependencies

#### Key Files
```
infra/bicep/
  main.bicep                         # Entry point (subscription scope)
  modules/static-web-app.bicep       # SWA module (reusable)
  parameters.dev.json                # Dev environment parameters
  parameters.prod.json               # Prod environment parameters
```

#### Quick Start
```bash
# Login to Azure
az login
az account set --subscription <YOUR_SUBSCRIPTION_ID>

# Validate
az deployment sub validate \
  --location eastus2 \
  --template-file infra/bicep/main.bicep \
  --parameters @infra/bicep/parameters.dev.json

# Deploy
az deployment sub create \
  --location eastus2 \
  --template-file infra/bicep/main.bicep \
  --parameters @infra/bicep/parameters.dev.json
```

---

### 3. Pulumi

**Directory:** `infra/pulumi/`

#### Pros
- **Real programming languages** - Use Python, TypeScript, Go, C#, or Java (no new DSL to learn)
- **Multi-cloud** - Supports Azure, AWS, GCP, Kubernetes, and more
- **Full language power** - Loops, conditionals, functions, classes, unit tests natively
- **Excellent secret management** - Secrets are encrypted by default in state
- **`pulumi preview`** - Detailed execution preview before deployment
- **Type safety** - IDE auto-complete and compile-time checks (especially TypeScript)
- **Testing** - Write unit and integration tests using standard testing frameworks
- **Pulumi AI** - AI-powered IaC generation from natural language

#### Cons
- **Smaller community** - Less mature ecosystem compared to Terraform
- **Runtime dependency** - Requires language runtime (Python, Node.js, etc.) installed
- **State management** - Requires Pulumi Cloud (free tier available) or self-managed backend
- **Cost** - Advanced features (policy as code, audit logs) require paid Pulumi Cloud
- **Over-engineering risk** - Full language power can lead to overly complex configurations
- **Azure provider lag** - Similar to Terraform, may lag behind Bicep on new Azure features

#### Key Files
```
infra/pulumi/
  __main__.py          # Main infrastructure program (Python)
  Pulumi.yaml          # Project definition
  Pulumi.dev.yaml      # Dev stack configuration
  requirements.txt     # Python dependencies
```

#### Quick Start
```bash
cd infra/pulumi

# Install dependencies
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Login to Pulumi (choose backend)
pulumi login                         # Pulumi Cloud (free)
# OR
pulumi login --local                 # Local state file

# Configure Azure credentials
export ARM_CLIENT_ID=<app-id>
export ARM_CLIENT_SECRET=<password>
export ARM_SUBSCRIPTION_ID=<sub-id>
export ARM_TENANT_ID=<tenant-id>

# Deploy
pulumi stack select dev
pulumi preview
pulumi up
```

---

## Detailed Feature Comparison

### Developer Experience

| Feature              | Terraform        | Bicep            | Pulumi           |
| -------------------- | ---------------- | ---------------- | ---------------- |
| Syntax highlighting  | Yes              | Yes              | Yes              |
| Auto-completion      | Yes (via LSP)    | Yes (VS Code)    | Yes (IDE native) |
| Error messages       | Good             | Good             | Excellent        |
| Documentation        | Excellent        | Good             | Good             |
| Refactoring tools    | Limited          | Limited          | Full IDE support |
| Debugging            | Limited          | None             | Full debugger    |

### Operational Features

| Feature              | Terraform          | Bicep              | Pulumi             |
| -------------------- | ------------------ | ------------------ | ------------------ |
| Plan/Preview         | `terraform plan`   | `az what-if`       | `pulumi preview`   |
| Apply                | `terraform apply`  | `az deployment`    | `pulumi up`        |
| Destroy              | `terraform destroy`| Manual (az CLI)    | `pulumi destroy`   |
| Import existing      | Yes                | Limited            | Yes                |
| Drift detection      | Yes                | No                 | Yes                |
| Rollback             | Via state          | Redeploy previous  | Via state          |
| Dependency graph     | Automatic          | Automatic          | Automatic          |

### Team & Enterprise

| Feature               | Terraform            | Bicep               | Pulumi               |
| --------------------- | -------------------- | -------------------- | -------------------- |
| RBAC                  | TF Cloud/Enterprise  | Azure RBAC           | Pulumi Cloud         |
| Policy as Code        | Sentinel (paid)      | Azure Policy (free)  | CrossGuard (paid)    |
| Audit logging         | TF Cloud (paid)      | Azure Activity Log   | Pulumi Cloud (paid)  |
| SSO/SAML              | Enterprise only      | Azure AD (free)      | Enterprise only      |
| Cost estimation       | TF Cloud (paid)      | Azure Cost Mgmt      | Not built-in         |

---

## Recommendation

### Choose **Terraform** if:
- Your team manages **multi-cloud** infrastructure (Azure + AWS/GCP)
- You want the **largest community** and module ecosystem
- You need **drift detection** and robust state management
- Your organization already uses Terraform for other projects
- You want to hire for a widely-known skill set

### Choose **Bicep** if:
- You are **100% Azure-committed** and don't plan to use other clouds
- You want **zero-day Azure feature support** (fastest provider updates)
- You prefer **no state file management** (Azure handles it)
- You're migrating from **ARM templates** (automatic decompilation)
- You want a **free, license-worry-free** solution
- Your team already knows Azure CLI and Resource Manager concepts

### Choose **Pulumi** if:
- Your developers **prefer real programming languages** over DSLs
- You want to write **unit tests** for your infrastructure code
- You value **type safety and IDE auto-complete** in your IaC
- You need **complex logic** (dynamic resource generation, API calls during provisioning)
- Your team has strong **Python/TypeScript/Go** skills

### For This Project (Todo App Frontend)

> **Recommended: Bicep** (Best fit)
>
> **Rationale:**
> 1. The project is **already deployed on Azure** (Static Web Apps with existing GitHub Actions)
> 2. It's a **simple, single-service deployment** (Resource Group + Static Web App)
> 3. **No state file management** reduces operational overhead for a frontend app
> 4. **What-If preview** provides confidence before deploying
> 5. **Free and Azure-native** aligns with the existing Azure commitment
> 6. Parameter files for `dev`/`prod` make environment management clean
>
> **Runner-up: Terraform** - If the team plans to expand to multi-cloud or already has Terraform expertise

---

## Prerequisites

### Common Prerequisites
1. **Azure Account** with an active subscription
2. **Azure CLI** installed (`az --version >= 2.60`)
3. **Node.js 20+** for building the React application
4. **GitHub repository** with Actions enabled

### Azure Service Principal Setup
```bash
# Create a service principal for GitHub Actions
az ad sp create-for-rbac \
  --name "todo-app-github-actions" \
  --role contributor \
  --scopes /subscriptions/<SUBSCRIPTION_ID> \
  --sdk-auth

# Save the output JSON - you'll need these values as GitHub Secrets:
# AZURE_CLIENT_ID, AZURE_CLIENT_SECRET, AZURE_SUBSCRIPTION_ID, AZURE_TENANT_ID
```

### GitHub Secrets Required

| Secret Name                | Description                          | Required By     |
| -------------------------- | ------------------------------------ | --------------- |
| `AZURE_CLIENT_ID`          | Service Principal Application ID     | All             |
| `AZURE_CLIENT_SECRET`      | Service Principal Password           | All             |
| `AZURE_SUBSCRIPTION_ID`    | Azure Subscription ID                | All             |
| `AZURE_TENANT_ID`          | Azure AD Tenant ID                   | All             |
| `PULUMI_ACCESS_TOKEN`      | Pulumi Cloud API token               | Pulumi only     |

### Tool-Specific Prerequisites

| Tool      | Install Command                          | Version   |
| --------- | ---------------------------------------- | --------- |
| Terraform | `brew install terraform`                 | >= 1.5.0  |
| Bicep     | Included with Azure CLI                  | >= 0.25   |
| Pulumi    | `curl -fsSL https://get.pulumi.com \| sh`| >= 3.0.0  |

---

## CI/CD Workflows

Three GitHub Actions workflows are provided:

| Workflow File                      | IaC Tool   | Trigger                              |
| ---------------------------------- | ---------- | ------------------------------------ |
| `.github/workflows/deploy-terraform.yml` | Terraform | Push to main / PR / Manual dispatch |
| `.github/workflows/deploy-bicep.yml`     | Bicep     | Push to main / PR / Manual dispatch |
| `.github/workflows/deploy-pulumi.yml`    | Pulumi    | Push to main / PR / Manual dispatch |

### Workflow Features
- **Automatic on push to main**: Provisions infrastructure + deploys app
- **PR Preview**: Shows plan/what-if/preview as PR comment
- **Manual dispatch**: Choose environment (dev/staging/prod) and action (plan/apply/destroy)
- **Two-stage pipeline**: Infrastructure provisioning -> App build & deploy

> **Note:** Enable only ONE workflow at a time. Disable the others to avoid conflicts.

---

## Cost Estimates

| Resource               | Free Tier         | Standard Tier     |
| ---------------------- | ----------------- | ----------------- |
| Static Web App         | $0/month          | ~$9/month         |
| Bandwidth (100GB)      | Included          | Included          |
| Custom domains         | 2 free            | 5 included        |
| SSL certificates       | Free (automatic)  | Free (automatic)  |
| Staging environments   | 3                 | 10                |
| **Total (estimated)**  | **$0/month**      | **~$9/month**     |

---

## Directory Structure

```
.
├── .github/
│   └── workflows/
│       ├── azure-static-web-apps-yellow-sky-01989f000.yml  # Original workflow
│       ├── deploy-terraform.yml    # Terraform CI/CD
│       ├── deploy-bicep.yml        # Bicep CI/CD
│       └── deploy-pulumi.yml       # Pulumi CI/CD
├── infra/
│   ├── terraform/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── terraform.tfvars.example
│   ├── bicep/
│   │   ├── main.bicep
│   │   ├── modules/
│   │   │   └── static-web-app.bicep
│   │   ├── parameters.dev.json
│   │   └── parameters.prod.json
│   └── pulumi/
│       ├── __main__.py
│       ├── Pulumi.yaml
│       ├── Pulumi.dev.yaml
│       └── requirements.txt
├── src/                             # React application source
├── dist/                            # Build output
├── package.json
├── vite.config.js
└── index.html
```
